///////////////////
// COMMANDS
///////////////////

// npm init -y 
/////////////////////
// to create package.json file in fresh project

// npm install 
/////////////////////
// to install node modules

// node server.js 
/////////////////////
// to run server (file name server.js could be anything -> its a file where we create our server and define all our routes)

// npm i package-name  
/////////////////////
// to install specific package

// npm i -D package-name | npm i --save-dev package-name 
/////////////////////
// to install specific package for development environment

// npm uninstal package-name 
/////////////////////


///////////////////
// PACKAGES
///////////////////

// npm i express (********big lib********)
// https://expressjs.com/
// const express = require('express'); 
/////////////////////
// node is a fast js runtime environment but it doesn't support request handling function, 
// http method or serving Files. Experss is a layer built on the top of the Node js that helps 
// make APIs, http requests(get, post etc), web applications, cross platform mobile apps, 
// manage servers and routes.
// FEATURES OF EXPRESS: ///  
// Fast Server-Side Development:
// The features of node js help express saving a lot of time.
// Middleware:
// For request handling, we can use Middleware.
// Routing:
// It refers to how an application's endpoint's URLs respond to client requests.
// Templating:
// It provides templating engines to build dynamic content on the web pages by creating HTML 
// templates on the server. Also allows dynamic rendering of HTML Pages based on passing 
// arguments to templates.
// Database:
// It's fast to link with databases like MySQL, MongoDB, etc.
// Debugging:
// Express makes it easier as it identifies the exact part where bugs are.

// EJS (npm i ejs) 
// https://ejs.co/
// app.set('view engine', 'ejs');
/////////////////////
// EJS (Embedded JavaScript Templating) is one of the most popular template engines for JavaScript. 
// It lets us embed JavaScript code in a template language that is then used to generate HTML.
// Example:
// <% if (user) { %>
//   <h2><%= user.name %></h2>
// <% } %>

// npm i nodemon
// https://nodemon.io/
// const nodemon = require('nodemon'); 
/////////////////////
// after make changes in file we don't have to run server again
// HOW TO USE:
// In package.json, define dev command inside scripts object
// "scripts": {
//   "dev": "nodemon server.js"
// },
// after defining dev command (nodemon server.js) inside scripts object, now run npm run dev command 
// which will trigger nodemon server.js command defined inside scripts object
// nodemon server.js command will not run directly by writing nodemon serverjs in terminal we 
// should use npm run dev

// npm i morgan
// https://www.npmjs.com/package/morgan
// const morgan = require('morgan'); 
/////////////////////
// Morgan is a middleware for node.js that logs HTTP requests and is commonly used in Express projects.
// Morgan simplifies the work of logging HTTP requests to and from your application in a single statement. 
// Normally, developers must write all of the logging code by hand. They must tell Node.js/Express.js 
// what to store, how to save, and where to save it.

// npm i mongoose (********big lib********)
// https://mongoosejs.com/docs/   
// const mongoose = require('mongoose');
/////////////////////
// mongoose is an Object Data Modeling(ODM) library for mongo db. It is a Object Relational Mapper(ORM) 
// that creates a connection between MongoDB and the Node.js. we don't have to write mongo db syntax to 
// communicate with it, we can use regular js syntax with the help of mongoose to communicate with mongodb
// Mongoose also provides security for data validation.

// npm i mysql2 (********big lib********)
// https://mysql2js.com/docs/   
// const mysql2 = require('mysql2');
/////////////////////
// mysql2 is an RDBMS library for mysql db. It is a RDBMS 
// that creates a connection between Mysql and the Node.js. we don't have to write mysql syntax to 
// communicate with it, we can use regular js syntax with the help of mysql2 to communicate with mysql.
// mysql2 also provides security for data validation.


// (npm i dotenv) 
// const dotenv = require('dotenv').config();
/////////////////////
// Dotenv is a zero-dependency module that loads environment variables from a .env


// (npm i joi) 
// https://joi.dev/api/?v=17.9.1
// const joi = require('joi');
/////////////////////
// used for form validation

// (npm i bcryptjs) 
// const bcrypt = require('bcryptjs');
/////////////////////
// used for hashing passwords etc
 
// npm i jsonwebtoken
/////////////////////
// for creating json web tokens fo rauthentication
/////////////////////
// Access Token VS Refresh Token
// Access tokens and refresh tokens are two types of JWTs used in authentication...
// Access tokens are used to grant access to resources, while refresh tokens are used to 
// request new access tokens when the current one expires. Access tokens have a short lifespan 
// and are stored on the client-side (e.g., in a cookie or local storage), while refresh tokens 
// have a longer lifespan and are stored on the server or a secure location on the client.

// crypto
// const crypto = require('crypto');
// crypto.randomBytes(64).toString('hex')
/////////////////////
// by default installed in node js
// used in terminal to generate random string

// (npm i cookie-parser) 
// const cookieParser = require('cookie-parser');
/////////////////////
// used for cookie based authentication, we don't send our token in response body, 
// because cookies are more secure



// npm i cors
// https://axios-http.com/docs/intro
// import cors from "cors"
/////////////////////
// cors is used for allowing cookies to be served, also allow frontend to send request to backend
// CORS is a node.js package for providing a Connect/Express middleware that can be used to enable CORS with various options.
// Example: