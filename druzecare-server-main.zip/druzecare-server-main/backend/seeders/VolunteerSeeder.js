
const Volunteer = require('../models/Volunteer'); // Import your Mongoose model
const colors = require('colors');

class VolunteerSeeder{
    // insert 
    static async insert() {
        try{
            // const seedData = [
            //     { name: 'Pending' },
            //     { name: 'Accepted' },
            //     { name: 'Rejected' }
            // ];

            // // insert data
            // await Volunteer.insertMany(seedData);

            console.log('Volunteer seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding Volunteer: ${error}`.red.inverse);
        }
      }

    // delete 
    static async delete() {
        try {
            // Delete all existing Volunteer
            await Volunteer.deleteMany();
            
            console.log('Volunteer deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting Volunteer: ${error}`.red.inverse);
        }
    }

}

module.exports = VolunteerSeeder;