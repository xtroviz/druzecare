
const ApprovalStatus = require('../models/ApprovalStatus'); // Import your Mongoose model
const colors = require('colors');

class ApprovalStatusSeeder{
    // insert 
    static async insert() {
        try{
            const seedData = [
                { name: 'Pending' },
                { name: 'Accepted' },
                { name: 'Rejected' }
            ];

            // insert data
            await ApprovalStatus.insertMany(seedData);

            console.log('ApprovalStatus seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding ApprovalStatus: ${error}`.red.inverse);
        }
      }

    // delete 
    static async delete() {
        try {
            // Delete all existing ApprovalStatus
            await ApprovalStatus.deleteMany();
            
            console.log('ApprovalStatus deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting ApprovalStatus: ${error}`.red.inverse);
        }
    }

}

module.exports = ApprovalStatusSeeder;