
const PasswordResetToken = require('../models/PasswordResetToken'); // Import your Mongoose model
const colors = require('colors');

class PasswordResetTokenSeeder{
    // insert 
    static async insert() {
        try{

            console.log('PasswordResetToken seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding PasswordResetToken: ${error}`.red.inverse);
        }
      }

      // delete 
    static async delete() {
        try {
            // Delete all existing Token
            await PasswordResetToken.deleteMany();
            
            console.log('PasswordResetToken deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting PasswordResetToken: ${error}`.red.inverse);
        }
    }

}

module.exports = PasswordResetTokenSeeder;