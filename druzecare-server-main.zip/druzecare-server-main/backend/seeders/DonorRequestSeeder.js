
const User = require('../models/User'); // Import your Mongoose model
const DonorRequest = require('../models/DonorRequest'); // Import your Mongoose model
const ApprovalStatus = require('../models/ApprovalStatus'); // Import your Mongoose model

const colors = require('colors');
const bcrypt = require('bcryptjs');

class DonorRequestSeeder{
    // insert 
    static async insert() {
        try{
            
            const donor = await User.find({role: "Donor"});
            const recipient = await User.find({role: "Recipient"});
            const approval_status = await ApprovalStatus.findOne({name: "Pending"});

            // console.log(donor[0]._id);
            
            const seedData = [
                { 
                    donor_id: donor[0]._id,
                    recipient_id: recipient[0]._id,
                    amount: 300,
                    type: "lumpsum",
                    approval_status_id: approval_status._id,
                },
                { 
                    donor_id: donor[1]._id,
                    recipient_id: recipient[0]._id,
                    amount: 300,
                    type: "lumpsum",
                    approval_status_id: approval_status._id,
                },
                { 
                    donor_id: donor[0]._id,
                    recipient_id: recipient[1]._id,
                    amount: 500,
                    type: "monthly",
                    approval_status_id: approval_status._id,
                },
                { 
                    donor_id: donor[1]._id,
                    recipient_id: recipient[1]._id,
                    amount: 500,
                    type: "monthly",
                    approval_status_id: approval_status._id,
                }
            ];

            // insert data
            await DonorRequest.insertMany(seedData);

            console.log('DonorRequest seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding DonorRequest: ${error}`.red.inverse);
        }
      }

      // delete 
    static async delete() {
        try {
            // Delete all existing DonorRequest
            await DonorRequest.deleteMany();
            
            console.log('DonorRequest deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting DonorRequest: ${error}`.red.inverse);
        }
    }

}

module.exports = DonorRequestSeeder;