
const Newsletter = require('../models/Newsletter'); // Import your Mongoose model
const colors = require('colors');

class NewsletterSeeder{
    // insert 
    static async insert() {
        try{
            // const seedData = [
            //     { name: 'Pending' },
            //     { name: 'Accepted' },
            //     { name: 'Rejected' }
            // ];

            // // insert data
            // await Newsletter.insertMany(seedData);

            console.log('Newsletter seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding Newsletter: ${error}`.red.inverse);
        }
      }

    // delete 
    static async delete() {
        try {
            // Delete all existing Newsletter
            await Newsletter.deleteMany();
            
            console.log('Newsletter deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting Newsletter: ${error}`.red.inverse);
        }
    }

}

module.exports = NewsletterSeeder;