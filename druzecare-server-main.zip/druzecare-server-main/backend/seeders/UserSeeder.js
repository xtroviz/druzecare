
const User = require('../models/User'); // Import your Mongoose model
const Country = require('../models/Country'); // Import your Mongoose model
const colors = require('colors');
const bcrypt = require('bcryptjs');

class UserSeeder{
    // insert 
    static async insert() {
        try{
            
            const pakistan = await Country.findOne({name: "Pakistan"});
            const india = await Country.findOne({name: "India"});
            
            // password hash
            const hash_password = await bcrypt.hash("demo2121", 10);
            
            const seedData = [
                { 
                    username: "admin",
                    firstname: "super",
                    lastname: "admin",
                    email: "super.admin@gmail.com",
                    password: hash_password,
                    country_id: pakistan._id,
                    city: "Karachi",
                    role: "Super Admin",
                    is_active: true,
                },
                { 
                    username: "admin",
                    firstname: "admin",
                    lastname: "admin",
                    email: "admin@gmail.com",
                    password: hash_password,
                    phone: "12345678901",
                    country_id: pakistan._id,
                    city: "Islamabad",
                    role: "Admin",
                    is_active: true,
                    is_visible: true,
                },
                { 
                    username: "test1",
                    firstname: "ahsan",
                    lastname: "rao",
                    email: "test1@gmail.com",
                    password: hash_password,
                    phone: "12345678901",
                    country_id: pakistan._id,
                    city: "Karachi",
            
                    monthly_requested_amount: "1000",
                    lumpsum_requested_amount: null,
                    story: "lorem ipsum",
                    story_ar: "lorem ipsum",
            
                    role: "Recipient",
                    is_active: true,
                    is_visible: true
                },
                { 
                    username: "test2",
                    firstname: "sameed",
                    lastname: "ali",
                    // email: "ahsan1@gmail.com",
                    password: hash_password,
                    phone: "12345678902",
                    country_id: india._id,
                    city: "Mumbai",
            
                    monthly_requested_amount: "1000",
                    lumpsum_requested_amount: null,
                    story: "lorem ipsum2",
                    story_ar: "lorem ipsum2",
            
                    role: "Recipient",
                    is_active: true,
                    is_visible: true
                },
                { 
                    username: "test3",
                    firstname: "ali",
                    lastname: "raza",
                    email: "ali@gmail.com",
                    password: hash_password,
                    phone: "12345678903",
                    country_id: pakistan._id,
                    city: "Karachi",
                    role: "Donor",
                    is_active: true,
                    is_visible: false
                },
                { 
                    username: "test4",
                    firstname: "faraz",
                    lastname: "husain",
                    email: "faraz@gmail.com",
                    password: hash_password,
                    phone: "12345678904",
                    country_id: india._id,
                    city: "Mumbai",
                    role: "Donor",
                    is_active: true,
                    is_visible: true
                }

            ];

            // insert data
            await User.insertMany(seedData);

            console.log('User seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding User: ${error}`.red.inverse);
        }
      }

      // delete 
    static async delete() {
        try {
            // Delete all existing User
            await User.deleteMany();
            
            console.log('User deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting User: ${error}`.red.inverse);
        }
    }

}

module.exports = UserSeeder;