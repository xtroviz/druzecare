
const Token = require('../models/Token'); // Import your Mongoose model
const colors = require('colors');

class TokenSeeder{
    // insert 
    static async insert() {
        try{

            console.log('Token seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding Token: ${error}`.red.inverse);
        }
      }

      // delete 
    static async delete() {
        try {
            // Delete all existing Token
            await Token.deleteMany();
            
            console.log('Token deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting Token: ${error}`.red.inverse);
        }
    }

}

module.exports = TokenSeeder;