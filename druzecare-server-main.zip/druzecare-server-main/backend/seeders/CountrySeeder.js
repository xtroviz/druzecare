
const Country = require('../models/Country'); // Import your Mongoose model
const colors = require('colors');

class CountrySeeder{
    // insert 
    static async insert() {
        try{
            const seedData = [
                { name: 'USA', status: 1 },
                { name: 'Pakistan', status: 1 },
                { name: 'India', status: 1 }
            ];

            // insert data
            await Country.insertMany(seedData);

            console.log('Country seeded successfully'.green.inverse);
        }
        catch(error){
          console.log(`Error seeding country: ${error}`.red.inverse);
        }
      }

    // delete 
    static async delete() {
        try {
            // Delete all existing Country
            await Country.deleteMany();
            
            console.log('Country deleted successfully'.green.inverse);
        } catch (error) {
            console.error(`Error deleting Country: ${error}`.red.inverse);
        }
    }

}

module.exports = CountrySeeder;