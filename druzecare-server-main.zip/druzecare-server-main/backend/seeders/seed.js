// Import required modules
const colors = require('colors');
const fs = require('fs'); // Import the fs module
const db_conn = require('../database/index');
const CountrySeederClass = require('./CountrySeeder');
const UserSeederClass = require('./UserSeeder');
const TokenSeederClass = require('./TokenSeeder');
const DonorRequestSeederClass = require('./DonorRequestSeeder');
const ApprovalStatusSeederClass = require('./ApprovalStatusSeeder');
const NewsletterSeederClass = require('./NewsletterSeeder');
const VolunteerSeederClass = require('./VolunteerSeeder');
const PasswordResetTokenSeederClass = require('./PasswordResetTokenSeeder');



// Import other seeder files as needed

// Run all seeder files
async function seedAll() {
    try {
        // connect database
        db_conn();

        // node seeders/seed.js RoleSeeder -i
        // node seeders/seed.js RoleSeeder -d
        // node seeders/seed.js -i
        // node seeders/seed.js -d

        // Call other seeder functions as needed
        if (process.argv[2].toLowerCase().includes('seeder')) { // to run one seeder
            
            // Get the seeder class name from command-line arguments
            const className = process.argv[2];
            // Create an instance of the seeder class dynamically
            const seeder = createSeederInstance(className);
            
            if (process.argv[3] === '-i') {
                await seeder.insert();
            }
            if (process.argv[3] === '-d') {
                await seeder.delete();
            }
        }
        else { // to run all seeders

            if (process.argv[2] === '-i') {
                await ApprovalStatusSeederClass.insert(); 
                await CountrySeederClass.insert();
                await UserSeederClass.insert();
                await TokenSeederClass.insert();
                await DonorRequestSeederClass.insert();  
                await NewsletterSeederClass.insert();   
                await VolunteerSeederClass.insert();   
            }

            if (process.argv[2] === '-d') {
                await ApprovalStatusSeederClass.delete();  
                await CountrySeederClass.delete();
                await UserSeederClass.delete();
                await TokenSeederClass.delete();
                await DonorRequestSeederClass.delete();
                await NewsletterSeederClass.delete();   
                await VolunteerSeederClass.delete();   
                await PasswordResetTokenSeederClass.delete();   
                
            }
            
        }

        console.log('All seeders executed successfully'.green.inverse);
    } catch (error) {
        console.error(`Error seeding database: ${error}`.red.inverse);
    } finally {
        process.exit(); // Exit the Node.js process
    }
}

function createSeederInstance(className, type = "single") {
    const seederClasses = {};
    // Read all files in the seeders directory
    const files = fs.readdirSync('./seeders');
    // Iterate over the files
    files.forEach(file => {
        // Check if the file is a JavaScript file
        if (file.endsWith('.js')) {
            // Extract the class name from the file name
            const className = file.replace('.js', '');
            // Import the seeder class dynamically
            const seederClass = require(`./${file}`);
            // Store the seeder class in the map
            seederClasses[className] = seederClass;
        }
    });
    // Check if the seeder class exists in the map
    if (seederClasses.hasOwnProperty(className)) {
        // Create an instance of the seeder class
        return new seederClasses[className]();
    } else {
        throw new Error(`Seeder class "${className}" not found`.red.inverse);
    }
}

seedAll();