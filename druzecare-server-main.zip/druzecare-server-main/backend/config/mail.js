// getting-started.js
const nodemailer = require('nodemailer');

const {  MAIL_MAILER, MAIL_HOST, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD, MAIL_ENCRYPTION, MAIL_SECURE,} = require('./index'); // using destructuring


// create reusable transporter object using the default SMTP transport
const transporter = nodemailer.createTransport({
  port: MAIL_PORT,               // true for 465, false for other ports
  host: MAIL_HOST,
     auth: {
          user: MAIL_USERNAME,
          pass: MAIL_PASSWORD,
       },
  // secure: MAIL_SECURE,
  });

module.exports = transporter;
