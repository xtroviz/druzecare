const Joi = require('joi');
const Country = require('../models/Country');
const ApprovalStatus = require('../models/ApprovalStatus');
const CountryDTO = require('../dto/country');

const mongodbIdPattern = /^[0-9a-fA-F]{24}$/;

const generalController = {
    
    async getCountries(req, res, next){

        let countries;

        try{
            countries = await Country.find({});
        }
        catch(error){
            return next(error);
        }

        let countriesDto = [];

        for(let i = 0; i < countries.length; i++){
            const obj = new CountryDTO(countries[i]);
            countriesDto.push(obj);
        }

        return res.status(200).json({data: countriesDto});
    },
    
    async getApprovalStatuses(req, res, next){

        let approval_statuses = [];

        try{
            approval_statuses = await ApprovalStatus.find({}).select('_id name');
        }
        catch(error){
            return next(error);
        }

        return res.status(200).json({data: approval_statuses});
    }
}

module.exports = generalController;