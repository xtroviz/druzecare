const Joi = require('joi');
const User = require('../models/User');
const Country = require('../models/Country');
const UserDTO = require('../dto/user');
const fs = require('fs');
const { BACKEND_SERVER_PATH } = require('../config/index');

const idPattern = /^[0-9a-fA-F]{24}$/;

const userController = {
  async index(req, res, next) {
    try {
      let query = {};

      // Parse query parameters
      const {
        id,
        country_id,
        role,
        created_by,
        is_active,
        is_visible,
        is_blocked,
        page,
        limit,
        sort_by,
        order,
        username,
        firstname,
        lastname,
        fullname,
        is_deleted,
      } = req.query;

      // Apply filters
      id && (query._id = id);
      country_id && (query.country_id = country_id);

      // sensitive filters start
      if(role == "" || role == 'Super Admin'){
        role && (query.role = { $ne: 'Super Admin' });
      }
      else {
        role && (query.role = role);
      }
      created_by && (query.created_by = created_by);
      is_visible && (query.is_visible = is_visible);
      is_blocked && (query.is_blocked = is_blocked);
      is_active && (query.is_active = is_active);
      is_deleted && (query.is_deleted = is_deleted);
      // sensitive filters end

      username && (query.username = { $regex: new RegExp(username, 'i') });
      firstname && (query.firstname = { $regex: new RegExp(firstname, 'i') });
      lastname && (query.lastname = { $regex: new RegExp(lastname, 'i') });

      // Add filter for fullname (combination of firstname and lastname)
      if (fullname) {
        const [firstname, lastname] = fullname.split(' ');
        if (firstname && lastname) {
          query.$or = [
            { firstname: { $regex: new RegExp(firstname, 'i') }, lastname: { $regex: new RegExp(lastname, 'i') } },
            { lastname: { $regex: new RegExp(`${firstname}\\s+${lastname}`, 'i') } },
          ];
        } else if (firstname) {
          query.$or = [
            { firstname: { $regex: new RegExp(firstname, 'i') } },
            { lastname: { $regex: new RegExp(firstname, 'i') } },
          ];
        }
      }

      // Execute query with pagination and sorting
      const users = await User.find(query)
        .populate('country_id')
        .sort({ [sort_by]: order === 'asc' ? 1 : -1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit));

      const totalUserCount = await User.find(query).count();

      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // 2. define the shape of output response
      const usersDTO = [];

      for (let i = 0; i < users.length; i++) {
        const dto = new UserDTO(users[i]);
        usersDTO.push(dto);
      }

      // 3. return response
      return res.status(201).json({ user: usersDTO, total: totalUserCount });
    } catch (error) {
      return next(error); // send error to errorHandler middleware
    }
  },

  async update(req, res, next) {
    // 1. validate request body
    // we expect input data to be in such shape
    const validator = Joi.object({
      // id: Joi.string().regex(idPattern).required(),
      username: Joi.string().min(5).max(30).optional(),
      firstname: Joi.string().max(30).optional(),
      lastname: Joi.string().max(30).optional(),
      email: Joi.string().email().optional(),
      phone: Joi.string().optional(),
      country_id: Joi.string().regex(idPattern).optional(),
      city: Joi.string().optional(),
      monthly_requested_amount: Joi.number().optional(),
      lumpsum_requested_amount: Joi.number().optional(),
      story: Joi.string().optional(),
      role: Joi.string().optional(),
      is_visible: Joi.number().integer().optional(),
      is_active: Joi.number().integer().optional(),
      is_blocked: Joi.number().integer().optional(),
      // password: Joi.string().pattern(password_pattern).required(),
      // confirm_password: Joi.ref('password'),
    });

    try {
      // if error in validation -> return error via middleware
      const { error } = validator.validate(req.body);
      if (error) {
        return next(error); // return next middleware which is errorHandler, defined in server.js
      }

      // get data from request
      const {
        // id,
        username,
        firstname,
        lastname,
        email,
        phone,
        country_id,
        city,

        monthly_requested_amount,
        lumpsum_requested_amount,
        story,

        is_visible,
      } = req.body;

      const auth_user = req.user; // this user details coming from authentication middleware.

      // 2. get user details (already checked in middleware)
      // let user;
      // user = await User.findOne({_id: id});

      // if(!user) {
      //   const error = {
      //     status: 400,
      //     message: 'User not found'
      //   };

      //   return next(error); // send error to errorHandler middleware
      // }

      if(country_id) {
        
      const country_details = await Country.findOne({ _id: country_id });
      if (!country_details) {
        const error = {
          status: 401,
          message: 'Country not found',
        };
        return next(error); // send error to errorHandler middleware
      }
      }

      // validate, if username already exist
      const username_in_use = await User.exists({ username, _id: { $ne: auth_user._id } }); // _id: { $ne: auth_user._id } } => it exluded the current record
      if (username_in_use) {
        const error = {
          status: 409,
          message: 'Username not available, use another username',
        };

        return next(error); // send error to next middleware which is errorHandler in our project
      }

      if (email !== undefined) {
        // validate, if email already exist
        const email_in_use = await User.exists({ email, _id: { $ne: auth_user._id } }); // _id: { $ne: id } } => it exluded the current record
        if (email_in_use) {
          const error = {
            status: 409,
            message: 'Email already registered, use another email',
          };

          return next(error); // send error to next middleware which is errorHandler in our project
        }
      }

      let story_ar = null;

      if(story && role == 'Recipient') {
        try {
          
          story_ar = await translate({text: story, source: 'en', target: 'ar' });

        } catch (err) {
            console.error(err);
        }
      }

      // 3. update user to database
      await User.updateOne(
        { _id: auth_user._id },
        {
          username, // we can write in this way, if key: value name are same
          firstname,
          lastname,
          email,
          phone,
          country_id,
          city,

          monthly_requested_amount,
          lumpsum_requested_amount,
          story,
          story_ar,

          is_visible,
        },
        { upsert: true },
      );

      // 4. return response
      return res.status(201).json({ message: 'user updated successfully' });
    } catch (error) {
      return next(error); // send error to errorHandler middleware
    }
  },

  // delete account
  async delete(req, res, next) {
    // validate id
    // delete user

    // const validator = Joi.object({
    //   id: Joi.string().regex(idPattern).required(),
    // });

    // const { error } = validator.validate(req.params);
    // if(error) {
    //   return next(error); // return next middleware which is errorHandler, defined in server.js
    // }

    const auth_user = req.user;

    // delete user
    try {
      await User.updateOne(
        { _id: auth_user._id },
        {
          is_deleted: true,
        },
      );
    } catch (error) {
      return next(error);
    }

    return res.status(200).json({ message: 'account deleted' });
  },
};

module.exports = userController;
