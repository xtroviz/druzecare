const Joi = require('joi');
const Contactus = require('../models/Contactus');
const VolunteerDTO = require('../dto/contactus');

const idPattern = /^[0-9a-fA-F]{24}$/;

const contactusController = {
    
    async index(req, res, next){

        try{
            let volunteers;

            volunteers = await Contactus.find({});
            

            let volunteersDto = [];

            for(let i = 0; i < volunteers.length; i++){
                const obj = new VolunteerDTO(volunteers[i]);
                volunteersDto.push(obj);
            }

            return res.status(200).json({data: volunteersDto});}
        catch(error){
            return next(error);
        }
    },

    async create(req, res, next){
        const createVolunteerSchema = Joi.object({
            name: Joi.string().min(5).max(30).required(),
            email: Joi.string().email().required(),
            phone: Joi.string().required(),
            address: Joi.string().min(5).max(50).required(),
            message: Joi.string().required(),
        });
        try{
            const {error} = createVolunteerSchema.validate(req.body);

            if (error){
                return next(error);
            }

            const {name, email, phone, address, message} = req.body;

            // validate, if email already exist
            const email_in_use = await Contactus.exists({email});
            if(email_in_use) {
                const error = {
                    status: 200,
                    message: 'Your Request already submitted. Our team will contact you shortly.'
                };
                
                return next(error); // send error to next middleware which is errorHandler in our project
            }
    
            const newVolunteer = new Contactus({
                name, 
                email,
                address, 
                phone, 
                message,
            });

            const volunteer = await newVolunteer.save();
            const VolunteersDTO = new VolunteerDTO(volunteer);

            return res.status(201).json({volunteer: VolunteersDTO,message : "Request submitted successfully. Our team will contact you",status : "201"});
        }
        catch(error){
            return next(error);
        }
    },   

}

module.exports = contactusController;