const Joi = require('joi');
const Volunteer = require('../models/Volunteer');
const ApprovalStatus = require('../models/ApprovalStatus');
const VolunteerDTO = require('../dto/volunteer');

const idPattern = /^[0-9a-fA-F]{24}$/;

const volunteerController = {
    
    async index(req, res, next){

        try{
            let volunteers;

            volunteers = await Volunteer.find({}).populate('approval_status_id');
            let volunteers_count = await Volunteer.countDocuments();
            

            let volunteersDto = [];

            // volunteersDto
            for(let i = 0; i < volunteers.length; i++){
                const obj = new VolunteerDTO(volunteers[i]);
                volunteersDto.push(obj);
            }

            return res.status(200).json({total: volunteers_count, data: volunteersDto});}
        catch(error){
            return next(error);
        }
    },

    async create(req, res, next){
        const createVolunteerSchema = Joi.object({
            name: Joi.string().min(5).max(30).required(),
            email: Joi.string().email().required(),
            phone: Joi.string().required(),
            message: Joi.string(),
        });
        try{
            const {error} = createVolunteerSchema.validate(req.body);

            if (error){
                return next(error);
            }

            const {name, email, phone, message} = req.body;

            // validate, if email already exist
            const email_in_use = await Volunteer.exists({email});
            if(email_in_use) {
                const error = {
                    status: 200,
                    message: 'Your Request already submitted.'
                };
                
                return next(error); // send error to next middleware which is errorHandler in our project
            }

            const approval_status_id = await ApprovalStatus.findOne({name: 'Pending'});
            console.log(approval_status_id._id);
        
            const newVolunteer = new Volunteer({
                name, 
                email, 
                phone, 
                message,
                approval_status_id: approval_status_id._id
            });

            const volunteer = await newVolunteer.save();
            const VolunteersDTO = new VolunteerDTO(volunteer);

            return res.status(201).json({volunteer: VolunteersDTO,message : "Volunteer request submitted successfully. Our team will contact you",status : "201"});
        }
        catch(error){
            return next(error);
        }
    },

    
    async updateStatus(req, res, next) {

        // 1. validate request body
        // we expect input data to be in such shape
        const validator = Joi.object({
            _id: Joi.string().regex(idPattern).required(),
            approval_status_id: Joi.string().regex(idPattern).required(),
        });

        try {
            // if error in validation -> return error via middleware
            const {error} = validator.validate(req.body);
            if(error) {
            return next(error); // return next middleware which is errorHandler, defined in server.js
            }

            // get data from request 
            const { _id, approval_status_id } = req.body;


            // 2. get volunteer details
            let volunteer;
            volunteer = await Volunteer.findOne({_id});
            
            if(!volunteer) {
                const error = {
                    status: 400,
                    message: 'Volunteer not found'
                };
        
                return next(error); // send error to errorHandler middleware
            }

            // 2. get approva_status details
            let approva_status;
            approva_status = await ApprovalStatus.findOne({_id: approval_status_id});
            
            if(!approva_status) {
                const error = {
                    status: 400,
                    message: 'Approval Status not found'
                };
        
                return next(error); // send error to errorHandler middleware
            }

            // 3. update user to database
            await Volunteer.updateOne(
            {_id},
            { approval_status_id },
            {upsert: true}
            );

            // 4. return response
            return res.status(201).json({message: "Volunteer status updated successfully"});
        }
        catch(error) {
            return next(error); // send error to errorHandler middleware
        }
    },

}

module.exports = volunteerController;