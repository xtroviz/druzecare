const Joi = require('joi');
const User = require('../models/User');
const DonorRequest = require('../models/DonorRequest');
const ApprovalStatus = require('../models/ApprovalStatus');
const DonorRequestDTO = require('../dto/donorRequest');

const idPattern = /^[0-9a-fA-F]{24}$/;

const donorRequestController = {
    
    async index(req, res, next){

        try{
            let query = {};
            let auth_user = req.user;
      
            // Parse query parameters
            let { 
              id, 
              donor_id, 
              recipient_id, 
              approval_status_id, 
              page = 1, 
              limit = 10, 
              sort_by = 'created_at', 
              order = 'desc'
            } = req.query;

            // Apply filters
            if(auth_user.role == "Recipient") {
                query.recipient_id = auth_user._id;
            }
            else if(auth_user.role == "Donor") {
                query.donor_id = auth_user._id;
            }
            else if(auth_user.role == "Super Admin" || auth_user.role == "Admin" || auth_user.role == "Muktar") {
                (donor_id) && ( query.donor_id = donor_id );
                (recipient_id) && ( query.recipient_id = recipient_id );
            }

            (id) && ( query._id = id );
            (approval_status_id) && ( query.approval_status_id = approval_status_id );


            let donorRequests;

            donorRequests = await DonorRequest.find(query)
            .populate({
                path:'recipient_id', 
                populate:{
                    path:'country_id',
                    model:'Country'
                }
            })
            .populate({
                path:'donor_id', 
                populate:{
                    path:'country_id',
                    model:'Country'
                }
            })
            .populate({
                path:'approval_status_id'
            })
            .sort({ [sort_by]: order === 'asc' ? 1 : -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));

            // return res.status(200).json({data: donorRequests});
            

            let donorRequestsDto = [];

            for(let i = 0; i < donorRequests.length; i++){
                const obj = new DonorRequestDTO(donorRequests[i]);
                donorRequestsDto.push(obj);
            }

            return res.status(200).json({data: donorRequestsDto});
        }
        catch(error){
            return next(error);
        }
    },

    async create(req, res, next){
        const createDonorRequestSchema = Joi.object({
            recipient_id: Joi.string().regex(idPattern).required(),
            // donor_id: Joi.string().regex(idPattern).required(),
            amount: Joi.string().required(),
            type: Joi.string().required(),
        });
        try{
            const {error} = createDonorRequestSchema.validate(req.body);

            if (error){
                return next(error);
            }

            const auth_user = req.user;

            const {recipient_id, amount, type, approval_status_id} = req.body;

            // validate, if user exist or not
            let user;
            user = await User.findOne({_id: recipient_id});
            // user = await User.find({
            //     $and: [
            //         { _id: recipient_id },
            //         { _id: donor_id }
            //     ]
            // });
            
            if(!user) {
                const error = {
                    status: 400,
                    message: 'User not found'
                };
        
                return next(error); // send error to errorHandler middleware
            }

            const approval_status = await ApprovalStatus.findOne({name: "Pending"});
            if(!approval_status) {
                const error = {
                    status: 400,
                    message: 'Invalid status'
                };
        
                return next(error); // send error to errorHandler middleware
            }

            const newDonorRequest = new DonorRequest({
                recipient_id, 
                donor_id: auth_user._id, 
                amount, 
                type,
                approval_status_id: approval_status._id
            });

            const donorRequest = await newDonorRequest.save();
            const DonorRequestsDTO = new DonorRequestDTO(donorRequest);

            return res.status(201).json({donorRequest: DonorRequestsDTO});
        }
        catch(error){
            return next(error);
        }
    },

    
    async updateStatus(req, res, next) {

        // 1. validate request body
        // we expect input data to be in such shape
        const validator = Joi.object({
            _id: Joi.string().regex(idPattern).required(),
            approval_status_id: Joi.string().regex(idPattern).required(),
        });

        try {
            // if error in validation -> return error via middleware
            const {error} = validator.validate(req.body);
            if(error) {
                return next(error); // return next middleware which is errorHandler, defined in server.js
            }

            const auth_user = req.user;

            // get data from request 
            const { _id, approval_status_id } = req.body;
            
            // 0 => pending, 1 => accepted, 2 => rejected
            const approval_status = await ApprovalStatus.find({});

            
            // if recipient reject or mark as pending than skip internal validation
            if(approval_status_id == approval_status[1]._id ) {
                // validate, if recipient already has accepted request 
                let donor_request = await DonorRequest.findOne({approval_status_id: approval_status[1]._id, recipient_id: auth_user._id});
                
                if(donor_request) {
                    const error = {
                        status: 400,
                        message: 'You cannot accept more than one request'
                    };
            
                    return next(error); // send error to errorHandler middleware
                }
            }


            // validate, if donor_request exist or not
            donor_request = await DonorRequest.findOne({_id, recipient_id: auth_user._id});
            
            if(!donor_request) {
                const error = {
                    status: 400,
                    message: 'Bad Request'
                };
        
                return next(error); // send error to errorHandler middleware
            }

            // 2. get approva_status details
            let approva_status = await ApprovalStatus.findOne({_id: approval_status_id});
            
            if(!approva_status) {
                const error = {
                    status: 400,
                    message: 'Approval Status not found'
                };
        
                return next(error); // send error to errorHandler middleware
            }

            // 3. update user to database
            await DonorRequest.updateOne(
            {_id},
            { approval_status_id },
            {upsert: true}
            );

            // if recipient accept request than make other requests rejected
            if(approval_status_id == approval_status[1]._id ) {
                // 3. update DonorRequest to database
                await DonorRequest.updateMany(
                {_id: { $ne: _id }, recipient_id: auth_user._id},
                { approval_status_id: approval_status[2]._id },
                {upsert: true}
                );
            }

            // 4. return response
            return res.status(201).json({message: "Request status updated successfully"});
        }
        catch(error) {
            return next(error); // send error to errorHandler middleware
        }
    },

}

module.exports = donorRequestController;