const Joi = require('joi');
const User = require('../../models/User');
const Country = require('../../models/Country');
const UserDTO = require('../../dto/user');

const idPattern = /^[0-9a-fA-F]{24}$/;

const userController = {

  async index(req, res, next) {
    try {
      // 1. get all users
      const users = await User.find({ role: { $ne: 'Super Admin' } }).populate('country_id');
      
      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // 2. define the shape of output response
      const usersDTO = [];

      for(let i = 0; i < users.length; i++) {
        const dto = new UserDTO(users[i]);
        usersDTO.push(dto);
      }

      
      // 3. return response
      return res.status(201).json({user: usersDTO});
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }
  },
  
  
  async view(req, res, next) {

    // 1. validate request body
    // we expect input data to be in such shape
    const validator = Joi.object({
      id: Joi.string().regex(idPattern).required()
    });
    
    // if error in validation -> return error via middleware
    const {error} = validator.validate(req.params);
    if(error) {
      return next(error); // return next middleware which is errorHandler, defined in server.js
    }
    
    // get data from request 
    const {id} = req.params;

    try {
      // 1. get all users
      const user = await User.findOne({_id: id}).populate('country_id');
      
      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // 2. define the shape of output response
      const userDTO = new UserDTO(user);

      
      // 3. return response
      return res.status(201).json({user: userDTO});
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }
  },

  async create(req, res, next) {
    // validate user input
    // we expect input data to be in such shape
    const validator = Joi.object({
        username: Joi.string().min(5).max(30).required(),
        firstname: Joi.string().max(30).required(),
        lastname: Joi.string().max(30).required(),
        email: Joi.string().email().optional(),
        phone: Joi.string().optional(),
        country_id: Joi.string().regex(idPattern).required(),
        city: Joi.string().required(),
        monthly_requested_amount: Joi.number().optional(),
        lumpsum_requested_amount: Joi.number().optional(),
        story: Joi.string().optional(),
        role: Joi.string().required(),
        is_visible: Joi.number().integer().required(),
        is_active: Joi.number().integer().required(),
        // password: Joi.string().pattern(password_pattern).required(),
        password: Joi.string().min(8).max(30).required(),
        confirm_password: Joi.ref('password')
    });

    try{ 
        // if error in validation -> return error via middleware
        const {error} = validator.validate(req.body);
        if(error) {
            return next(error); // return next middleware which is errorHandler, defined in server.js
        }

        // get data from request 
        const { 
            username,
            firstname,
            lastname,
            email,
            password,
            phone,
            country_id,
            city,

            monthly_requested_amount,
            lumpsum_requested_amount,
            story,

            role,
            is_active,
            is_visible
        } = req.body;

        const auth_user = req.user;

        // this condition will check that the admin and muktar should not be able to create
        // super admin or admin
        if(auth_user.role == "Admin" || auth_user.role == "Muktar") {
            if(role == "Super Admin" || role == "Admin") {
                const error = {
                    status: 401,
                    message: 'You cannot create a user of this role',
                };
                return next(error); // send error to errorHandler middleware
            }
        }

        const country_details = await Country.findOne({_id:country_id});
        if(!country_details) {
            const error = {
            status: 401,
            message: 'Country not found',
            };
            return next(error); // send error to errorHandler middleware
        }


        // validate, if username already exist
        const username_in_use = await User.exists({username});
        if(username_in_use) {
            const error = {
            status: 409,
            message: 'Username not available, use another username'
            };

            return next(error); // send error to next middleware which is errorHandler in our project
        }

        if(email !== undefined) {
            // validate, if email already exist
            const email_in_use = await User.exists({email});
            if(email_in_use) {
            const error = {
                status: 409,
                message: 'Email already registered, use another email'
            };
            
            return next(error); // send error to next middleware which is errorHandler in our project
            }
        }
            
        // password hash
        const hash_password = await bcrypt.hash(password, 10);

        
        let story_ar = null;

        if(role == 'Recipient') {
          try {
            
            story_ar = await translate({text: story, source: 'en', target: 'ar' });

          } catch (err) {
              console.error(err);
          }
        }

        // store user data in database
        const user_store = new User({
            username, // we can write in this way, if key: value name are same
            
            firstname,
            lastname,
            email,
            password: hash_password,
            phone,
            country_id,
            city,

            monthly_requested_amount,
            lumpsum_requested_amount,
            story,
            story_ar,

            role,
            is_visible,
            is_active,
            created_by: auth_user._id,
        });
        
        const user = await user_store.save();
        
        // Data Transfer Object (DTO) -> return data in what format
        // which fields should return in the response
        // define the shape of output response
        const user_dto = new UserDTO(user); // send user object to get only fields, to return in response
        
        return res.status(201).json({user: user_dto, auth: true});
    }
    catch(error) {
    return next(error); // send error to errorHandler middleware
    }
  },

  async update(req, res, next) {

    // 1. validate request body
    // we expect input data to be in such shape
    const validator = Joi.object({
        id: Joi.string().regex(idPattern).required(),
        username: Joi.string().min(5).max(30).optional(),
        firstname: Joi.string().max(30).optional(),
        lastname: Joi.string().max(30).optional(),
        email: Joi.string().email().optional(),
        phone: Joi.string().optional(),
        country_id: Joi.string().regex(idPattern).optional(),
        city: Joi.string().optional(),
        monthly_requested_amount: Joi.number().optional(),
        lumpsum_requested_amount: Joi.number().optional(),
        story: Joi.string().optional(),
        role: Joi.string().optional(),
        is_visible: Joi.number().integer().optional(),
        is_active: Joi.number().integer().optional(),
        is_blocked: Joi.number().integer().optional(),
        // password: Joi.string().pattern(password_pattern).optional(),
        password: Joi.string().min(8).max(30).optional(),
        confirm_password: Joi.ref('password'),
    });

    try {
        // if error in validation -> return error via middleware
        const {error} = validator.validate(req.body);
        if(error) {
          return next(error); // return next middleware which is errorHandler, defined in server.js
        }

        // get data from request 
        const {
          username,
          firstname,
          lastname,
          email,
          phone,
          country_id,
          password,
          city,
  
          monthly_requested_amount,
          lumpsum_requested_amount,
          story,
  
          role,
          is_visible,
          is_active
        } = req.body;

        const auth_user = req.user; // this user details coming from authentication middleware.

        if(auth_user.role == "Admin" || auth_user.role == "Muktar") {
            if(role == "Super Admin" || role == "Admin") {
                const error = {
                    status: 401,
                    message: 'You cannot create a user of this role',
                };
                return next(error); // send error to errorHandler middleware
            }
        }


        // 2. get user details
        let user;
        user = await User.findOne({_id: id});
        
        if(!user) {
          const error = {
            status: 400,
            message: 'User not found'
          };
  
          return next(error); // send error to errorHandler middleware
        }

        if(country_id) {

          const country_details = await Country.findOne({_id:country_id});
          if(!country_details) {
            const error = {
              status: 401,
              message: 'Country not found',
            };
            return next(error); // send error to errorHandler middleware
          }
        }


        // validate, if username already exist
        const username_in_use = await User.exists({username, _id: { $ne: id } });
        if(username_in_use) {
          const error = {
            status: 409,
            message: 'Username not available, use another username'
          };
  
          return next(error); // send error to next middleware which is errorHandler in our project
        }
  
        if(email !== undefined) {
          // validate, if email already exist
          const email_in_use = await User.exists({email, _id: { $ne: id } });
          if(email_in_use) {
            const error = {
              status: 409,
              message: 'Email already registered, use another email'
            };
            
            return next(error); // send error to next middleware which is errorHandler in our project
          }
        }
  
      
      // password hash
      const hash_password = await bcrypt.hash(password, 10);
  
      let story_ar = null;

      if(story && role == 'Recipient') {
        try {
          
          story_ar = await translate({text: story, source: 'en', target: 'ar' });

        } catch (err) {
            console.error(err);
        }
      }

        
        // 3. update user to database
        await User.updateOne(
          {_id: id},
          {
            username, // we can write in this way, if key: value name are same
            firstname,
            lastname,
            email,
            phone,
            country_id,
            city,
            password: hash_password,

            monthly_requested_amount,
            lumpsum_requested_amount,
            story,
            story_ar,

            role,
            is_visible,
            is_active,
            created_by: auth_user._id,
          },
          {upsert: true}
        );

        // 4. return response
        return res.status(201).json({message: "user updated successfully"});
      }
      catch(error) {
        return next(error); // send error to errorHandler middleware
      }
  },

  async delete(req, res, next) {

    const validator = Joi.object({
      id: Joi.string().regex(idPattern).required(),
    });

    try {
        const { error } = validator.validate(req.params);
        if(error) {
            return next(error); // return next middleware which is errorHandler, defined in server.js
        }

        const { id } = req.params;

        let user;
        user = await User.findOne({_id: id});
        
        const auth_user = req.user; // this user details coming from authentication middleware.

        if(auth_user.role == "Admin" || auth_user.role == "Muktar") {
            if(user.role == "Super Admin" || user.role == "Admin") {
                const error = {
                    status: 401,
                    message: 'You cannot delete a user of this role',
                };
                return next(error); // send error to errorHandler middleware
            }
        }

        // delete user
        await User.updateOne(
            {_id: id},
            {
              is_deleted: true
            }
        );

        return res.status(200).json({ message: "user deleted" });
    } catch (error) {
      return next(error);
    }
  },

}

module.exports = userController;