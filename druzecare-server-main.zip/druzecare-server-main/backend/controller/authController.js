const Joi = require('joi');
const util = require('util');
const User = require('../models/User');
const Country = require('../models/Country');
const UserDTO = require('../dto/user');
const bcrypt = require('bcryptjs');
const JWTService = require('../services/JWTService');
const RefreshToken = require('../models/Token');
const PasswordResetToken = require('../models/PasswordResetToken');
const transporter = require('../config/mail');

const translate = require('node-google-translate-skidz');


const {FRONTEND_SERVER_PATH, MAIL_FROM_ADDRESS, MAIL_FROM_NAME, SUPPORT_MAIL_ADDRESS} = require('../config/index'); // using destructuring


const password_pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,25}$/;
const idPattern = /^[0-9a-fA-F]{24}$/;
const authController = {


  async register(req, res, next) {
    // validate user input
    // we expect input data to be in such shape
    const validator = Joi.object({
      username: Joi.string().min(5).max(30).required(),
      firstname: Joi.string().max(30).required(),
      lastname: Joi.string().max(30).required(),
      email: Joi.string().email().required(),
      phone: Joi.string().optional(),
      country_id: Joi.string().regex(idPattern).required(),
      city: Joi.string().required(),
      monthly_requested_amount: Joi.number().optional(),
      lumpsum_requested_amount: Joi.number().optional(),
      story: Joi.string().optional(),
      role: Joi.string().required(),
      is_visible: Joi.number().integer().required(),
      is_active: Joi.number().integer().required(),
      created_by: Joi.string().optional(),
      password: Joi.string().min(8).max(30).required(),
      // password: Joi.string().pattern(password_pattern).required(),
      confirm_password: Joi.ref('password'),
    });

    try{ 
      // if error in validation -> return error via middleware
      const {error} = validator.validate(req.body);
      if(error) {
        return next(error); // return next middleware which is errorHandler, defined in server.js
      }

      // get data from request 
      const { 
        username,
        firstname,
        lastname,
        email,
        password,
        phone,
        country_id,
        city,

        monthly_requested_amount,
        lumpsum_requested_amount,
        story,

        role,
        is_active,
        is_visible,
        created_by
      } = req.body;


      const country_details = await Country.findOne({_id:country_id});
      if(!country_details) {
        const error = {
          status: 401,
          message: 'Country not found',
        };
        return next(error); // send error to errorHandler middleware
      }


      // validate, if username already exist
      const username_in_use = await User.exists({username});
      if(username_in_use) {
        const error = {
          status: 409,
          message: 'Username not available, use another username'
        };

        return next(error); // send error to next middleware which is errorHandler in our project
      }

      if(email !== undefined) {
        // validate, if email already exist
        const email_in_use = await User.exists({email});
        if(email_in_use) {
          const error = {
            status: 409,
            message: 'Email already registered, use another email'
          };
          
          return next(error); // send error to next middleware which is errorHandler in our project
        }
      }
        
      
      // password hash
      const hash_password = await bcrypt.hash(password, 10);

      let story_ar = null;
      if(role == 'Recipient') {
        try {
          
          story_ar = await translate({text: story, source: 'en', target: 'ar' });

        } catch (err) {
            console.error(err);
        }
      }

    
      // store user data in database
      const user_store = new User({
        username, // we can write in this way, if key: value name are same
        firstname,
        lastname,
        email,
        password: hash_password,
        phone,
        country_id,
        city,

        monthly_requested_amount,
        lumpsum_requested_amount,
        story,
        story_ar,

        role,
        is_visible,
        is_active,
        created_by,
      });
      
      const user = await user_store.save();
      
      
      // Token Generation
      
      // Access Token VS Refresh Token
      // Access tokens and refresh tokens are two types of JWTs used in authentication...
      // Access tokens are used to grant access to resources, while refresh tokens are used to 
      // request new access tokens when the current one expires. Access tokens have a short lifespan 
      // and are stored on the client-side (e.g., in a cookie or local storage), while refresh tokens 
      // have a longer lifespan and are stored on the server or a secure location on the client.
      
      // create new access token for user
      let accessToken = JWTService.signAccessToken({_id: user._id}, '30d');
      // create new refresh token for user
      let refreshToken = JWTService.signRefreshToken({_id: user._id}, '40d');
      
      // store refresh token in db
      // Used to request a new access token when the current one expires 
      await JWTService.storeRefreshToken(refreshToken, user._id);
      
      // send access token in cookie
      // we can send token in (http header, url parameter, cookie)
      res.cookie('accessToken', accessToken, {
        // 1000 ms = 1 sec
        maxAge: 1000 * 60 * 60 * 24 * 30, // -> 1 day expiry time 
        httpOnly: true  
        // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
        // also secure us from XSS
      });

      // send refresh token in cookie
      res.cookie('refreshToken', refreshToken, {
        // 1000 ms = 1 sec
        maxAge: 1000 * 60 * 60 * 24 * 40, // -> 1 day expiry time
        httpOnly: true  
        // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
        // also secure us from XSS
      });
      
    
      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // define the shape of output response
      const user_dto = new UserDTO(user); // send user object to get only fields, to return in response
      res.cookie('role', user_dto.role, {
        // 1000 ms = 1 sec
        maxAge: 1000 * 60 * 60 * 24 * 30, // -> 1 day expiry time
        httpOnly: true  
        // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
        // also secure us from XSS
      });
      return res.status(201).json({user: user_dto,role:user_dto.role,accessToken: accessToken,refreshToken: refreshToken,auth: true});
      
    }
    catch(error) {

      return next(error); // send error to errorHandler middleware
    }
  },

  async login(req, res, next) {
    // 1. validate user input
    // we expect input data to be in such shape
    const validator = Joi.object({
      username: Joi.string().min(5).max(30).required(),
      password: Joi.string().min(5).max(30).required(),
      // password: Joi.string().pattern(password_pattern).required()
    });

    // if error in validation -> return error via middleware
    const {error} = validator.validate(req.body);
    if(error) {
      return next(error); // return next middleware which is errorHandler used in server.js
    }

    
    // get data from request 
    const {username, password} = req.body;

    // validate, if username or email already exist
    try{
      
      // find user with username
      const user = await User.findOne({username});
      if(!user) {
        const error = {
          status: 401,
          message: 'Invalid username'
        };
        return next(error); // send error to errorHandler middleware
      }

      // match password if username exist
      const match = await bcrypt.compare(password, user.password);  
      if(!match) {
        const error = {
          status: 401,
          message: 'Invalid password'
        };
        return next(error); // send error to errorHandler middleware
      }

      
      
      // Token Generation
      
      // Access Token VS Refresh Token
      // Access tokens and refresh tokens are two types of JWTs used in authentication...
      // Access tokens are used to grant access to resources, while refresh tokens are used to 
      // request new access tokens when the current one expires. Access tokens have a short lifespan 
      // and are stored on the client-side (e.g., in a cookie or local storage), while refresh tokens 
      // have a longer lifespan and are stored on the server or a secure location on the client.
      
      // create new access token for user
      let accessToken = JWTService.signAccessToken({_id: user._id}, '30d');
      // create new refresh token for user
      let refreshToken = JWTService.signRefreshToken({_id: user._id}, '40d');
      
      // update refresh token for user if already exist in database
      try {
        await RefreshToken.updateOne(
          { userId: user._id },
          { token: refreshToken },
          { upsert: true }
        );  
      } 
      catch (error) {
        return next(error); // send error to errorHandler middleware
      }
      
      // send access token in cookie
      // we can send token in (http header, url parameter, cookie)
      res.cookie('accessToken', accessToken, {
        // 1000 ms = 1 sec
        maxAge: 1000 * 60 * 60 * 24 * 30, // -> 1 day expiry time 
        httpOnly: true  
        // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
        // also secure us from XSS
      });

      // send refresh token in cookie
      res.cookie('refreshToken', refreshToken, {
        // 1000 ms = 1 sec
        maxAge: 1000 * 60 * 60 * 24 * 40, // -> 1 day expiry time
        httpOnly: true  
        // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
        // also secure us from XSS
      });



      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // define the shape of output response
      const user_dto = new UserDTO(user); // send user object User DTO to get only useful fields, to return in response
      
      res.cookie('role', user_dto.role, {
        // 1000 ms = 1 sec
        maxAge: 1000 * 60 * 60 * 24 * 30, // -> 1 day expiry time
        httpOnly: true  
        // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
        // also secure us from XSS
      });
      return res.status(200).json({user: user_dto,role:user_dto.role,accessToken: accessToken,refreshToken: refreshToken, auth: true});
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }


  },

  async forgotPassword(req, res, next) {
    // 1. validate user input
    // we expect input data to be in such shape
    const validator = Joi.object({
      email: Joi.string().email().required(),
    });

    // if error in validation -> return error via middleware
    const {error} = validator.validate(req.body);
    if(error) {
      return next(error); // return next middleware which is errorHandler used in server.js
    }

    
    // get data from request 
    const {email} = req.body;

    // validate, if email already exist
    try{
      
      // find user with email
      const user = await User.findOne({email});
      if(!user) {
        const error = {
          status: 401,
          message: 'Invalid email'
        };
        return next(error); // send error to errorHandler middleware
      }

      // delete all token for user if exist in database
      await PasswordResetToken.deleteMany(
        { email: user.email }
      );  
      
      // Token Generation
      
      // create new signPasswordResetToken token for user
      let passwordResetToken = JWTService.signPasswordResetToken({email: user.email}, '30m');
      
      // store passwordResetToken token in db
      // Used to request a new storePasswordResetToken token when the current one expires 
      await JWTService.storePasswordResetToken(user.email, passwordResetToken);

      const mailData = {
          from: MAIL_FROM_ADDRESS,
          to: user.email,
          subject: "Reset Password Notification",
          text: "Reset Password Notification1",
          html: `<b>Hey there! </b><br> update password<br/><a href="${FRONTEND_SERVER_PATH}/reset-password/${passwordResetToken}">${FRONTEND_SERVER_PATH}/reset-password/${passwordResetToken}</a>`,
      };
  
      transporter.sendMail(mailData, (error, info) => {
          if (error) {
              return next(error);
          }
          res.status(200).send({ message: "Mail send", message_id: info.messageId });
      });


      return res.status(200).json({message: "Email sent successfully"});
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }


  },


  
  async resetPassword(req, res, next) {
    // validate user input
    // we expect input data to be in such shape
    const bodyValidator = Joi.object({
      // password: Joi.string().pattern(password_pattern).required(),
      password: Joi.string().min(8).max(30).required(),
      confirm_password: Joi.ref('password')
    });
    const paramValidator= Joi.object({
        token: Joi.string().required()
    });
    // const queryValidator= Joi.object({
    //     email: Joi.string().email().required()
    // });

    try{ 
      // if error in validation -> return error via middleware
      const {bodyError} = bodyValidator.validate(req.body);
      if(bodyError) {
          return next(bodyError); // return next middleware which is errorHandler, defined in server.js
      }
      // if error in validation -> return error via middleware
      const {paramError} = paramValidator.validate(req.params);
      if(paramError) {
          return next(paramError); // return next middleware which is errorHandler, defined in server.js
      }
      // if error in validation -> return error via middleware
      // const {queryError} = queryValidator.validate(req.query);
      // if(queryError) {
      //     return next(queryError); // return next middleware which is errorHandler, defined in server.js
      // }

      // get data from request 
      const { password } = req.body;
      
      const {token} = req.params;

      // const email = req.query.email;


      // it return payload of token
      // at the time of signAccessToken() in register and login function we send user id as payload
      // if verifyAccessToken() return _id as payload it means the accessToken which comes in req is valid
      const password_reset_token = await PasswordResetToken.findOne({token: token});  

      const email = JWTService.verifyPasswordResetToken(token).email;  

      let user = await User.findOne({email: email});  

      if(!user || !password_reset_token) {
        const error = {
          status: 401,
          message: 'UnAuthorized',
        };
        return next(error); // send error to errorHandler middleware
      }
      
      // delete all token for user if exist in database
      await PasswordResetToken.deleteMany(
        { email: user.email }
      );  



      // password hash
      const hash_password = await bcrypt.hash(password, 10);



      // 3. update user to database
      await User.updateOne(
        {email: user.email},
        {
          password: hash_password
        },
        {upsert: true}
      );

      return res.status(201).json({message: "password updated successfully"});
    }
    catch(error) {
    return next(error); // send error to errorHandler middleware
    }
  },

  async logout(req, res, next) {
    // 1. delete refresh token from db
    // const refreshToken = req.body.token;
    const {refreshToken} = req.cookies;

    try {
      await RefreshToken.deleteOne({token: refreshToken}); // delete refresh token from db
    } catch (error) {
      return next(error); // send error to errorHandler middleware
    }

    // 2. delete cookies 
    res.clearCookie('accessToken');
    res.clearCookie('refreshToken');

    // 3. return response
    res.status(200).json({user: null, auth: false});
  },

  async refresh(req, res, next) {
    
    // 1. get refresh token from cookies
    const originalRefreshToken = req.cookies.refreshToken;
    // const originalRefreshToken = req.body.token;
    
    // 2. verify refresh token
    let userId;
    try {
      // it return payload of token
      // at the time of signRefreshToken() in register and login function we send user_id as payload in token generation
      // if verifyRefreshToken() wil return _id as payload, it means the refreshToken which comes in req is valid
      userId = JWTService.verifyRefreshToken(originalRefreshToken)._id;

    } catch (e) {
      const error = {
        status: 401,
        message: 'Unauthorized'
      };

      return next(error); // send error to errorHandler middleware
    }
    
    try {
      // check if token with user_id exists in database
      const match = RefreshToken.findOne({userId: userId, token: originalRefreshToken});
      
      if(!match) {
        const error = {
          status: 401,
          message: 'Unauthorized'
        };
        return next(error); // send error to errorHandler middleware
      }
      
    } catch (error) {
      return next(error); // send error to errorHandler middleware
    }
    
    
    
    // 3. generate new tokens
    
    // Access Token VS Refresh Token
    // Access tokens and refresh tokens are two types of JWTs used in authentication...
    // Access tokens are used to grant access to resources, while refresh tokens are used to 
    // request new access tokens when the current one expires. Access tokens have a short lifespan 
    // and are stored on the client-side (e.g., in a cookie or local storage), while refresh tokens 
    // have a longer lifespan and are stored on the server or a secure location on the client.
    
    // create new access token for user
    let accessToken = JWTService.signAccessToken({_id: userId}, '30d');
    // create new refresh token for user
    let refreshToken = JWTService.signRefreshToken({_id: userId}, '40d');
    
    // 4. update refresh token for user if already exist in database
    try {
      await RefreshToken.updateOne(
        { userId: userId },
        { token: refreshToken },
        { upsert: true }
      );  
    } 
    catch (error) {
      return next(error); // send error to errorHandler middleware
    }
    
    // send access token in cookie
    // we can send token in (http header, url parameter, cookie)
    res.cookie('accessToken', accessToken, {
      // 1000 ms = 1 sec
      maxAge: 1000 * 60 * 60 * 24 * 30, // -> 1 day expiry time 
      httpOnly: true  
      // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
      // also secure us from XSS
    });

    // send refresh token in cookie
    res.cookie('refreshToken', refreshToken, {
      // 1000 ms = 1 sec
      maxAge: 1000 * 60 * 60 * 24 * 40, // -> 1 day expiry time
      httpOnly: true  
      // httpOnly -> cookie should be accessible only through the HTTP protocol and not through client-side JavaScript.
      // also secure us from XSS
    });

    
    let user;

    try {
      user = await User.findOne({_id: userId});  
    } catch (error) {
      return next(error);
    }

    // 5. return response
    // Data Transfer Object (DTO) -> return data in what format
    // which fields should return in the response
    // define the shape of output response
    const userDTO = new UserDTO(user); // send user object User DTO to get only useful fields, to return in response

    return res.status(200).json({user: userDTO,  auth: true});
  }
}

module.exports = authController;