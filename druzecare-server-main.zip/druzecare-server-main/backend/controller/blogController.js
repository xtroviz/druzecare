const Joi = require('joi');
const Blog = require('../models/Blog');
const Comment = require('../models/Comment');
const BlogDTO = require('../dto/blog');
const BlogDetailsDTO = require('../dto/blog_details');
const fs = require('fs');
const {BACKEND_SERVER_PATH} = require('../config/index');

const idPattern = /^[0-9a-fA-F]{24}$/;

const blogController = {
  
  async index(req, res, next) {
    try {
      // 1. get all blogs
      const blogs = await Blog.find({}).populate('author');
      
      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // 2. define the shape of output response
      const blogsDTO = [];

      for(let i = 0; i < blogs.length; i++) {
        const dto = new BlogDetailsDTO(blogs[i]);
        blogsDTO.push(dto);
      }
      
      
      // 3. return response
      return res.status(201).json({blog: blogsDTO});
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }
  },
  
  
  async view(req, res, next) {

    // 1. validate request body
    // we expect input data to be in such shape
    const validator = Joi.object({
      id: Joi.string().regex(idPattern).required()
    });
    
    // if error in validation -> return error via middleware
    const {error} = validator.validate(req.params);
    if(error) {
      return next(error); // return next middleware which is errorHandler, defined in server.js
    }
    
    // get data from request 
    const {id} = req.params;

    try {
      // 1. get all blogs
      const blog = await Blog.findOne({_id: id}).populate('author');
      
      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // 2. define the shape of output response
      const blogDTO = new BlogDetailsDTO(blog);

      
      // 3. return response
      return res.status(201).json({blog: blogDTO});
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }
  },
  
  async create(req, res, next) {

    // 1. validate request body
    // we expect input data to be in such shape
    const validator = Joi.object({
      title: Joi.string().required(),
      author: Joi.string().regex(idPattern).required(),
      content: Joi.string().required(),
      image: Joi.string().required(),
    });
    
    // if error in validation -> return error via middleware
    const {error} = validator.validate(req.body);
    if(error) {
      return next(error); // return next middleware which is errorHandler, defined in server.js
    }
    
    // get data from request 
    const {title, author, content, image} = req.body;
    
    // 2. handle image storage 
    
    // read as buffer
    // buffer is a built-in method for handling streams of binary data like file etc
    const buffer = Buffer.from( image.replace(/^data:image\/(png|jpg|jpeg);base64,/,''), 'base64' );
    
    // allot a random name
    const imageName = `${Date.now()}-${author}.png`;
    
    // save image locally
    try {
      fs.writeFileSync(`storage/${imageName}`, buffer);
    } catch (error) {
      return  next(error);
    }

    // 3. add blog to database
    try{
      // store blog data in database
      const blogStore = new Blog({
        title, // we can write in this way, if key: value name are same
        author,
        content,
        image: `${BACKEND_SERVER_PATH}/storage/${imageName}`
      });
      
      const blog = await blogStore.save();
      
      
      // Data Transfer Object (DTO) -> return data in what format
      // which fields should return in the response
      // define the shape of output response
      const blogDTO = new BlogDTO(blog); // send blog object to get only fields, to return in response
      
      // 4. return response
      return res.status(201).json({blog: blogDTO, auth: true});
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }

  },

  async update(req, res, next) {

    // 1. validate request body
    // we expect input data to be in such shape
    const validator = Joi.object({
      id: Joi.string().regex(idPattern).required(),
      author: Joi.string().regex(idPattern).required(),
      title: Joi.string(),
      content: Joi.string(),
      image: Joi.string(),
    });
    
    // if error in validation -> return error via middleware
    const {error} = validator.validate(req.body);
    // if(error) {
    //   return next(error); // return next middleware which is errorHandler, defined in server.js
    // }
    
    // get data from request 
    const {id, author, title, content, image} = req.body;

    // 2. get blog details
    let blog;
    try {
      
      blog = await Blog.findOne({_id: id, author: author});
      
      if(!blog) {
        const error = {
          status: 400,
          message: 'Blog not found'
        };

        return next(error); // send error to errorHandler middleware
      }

    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }

    
    // 3. handle image storage if exists 
    let imageName = blog.image;

    if(image) {
      // read as buffer
      // buffer is a built-in method for handling streams of binary data like file etc
      const buffer = Buffer.from( image.replace(/^data:image\/(png|jpg|jpeg);base64,/,''), 'base64' );
      
      // allot a random name
      imageName = `${Date.now()}-${author}.png`;
      
      // save image locally
      try {
        fs.writeFileSync(`storage/${imageName}`, buffer);

        // delete old image if new image save into storage
        let oldImageName = imageName;
        oldImageName = oldImageName.split('/').at(-1);
        fs.unlinkSync(`storage/${oldImageName}`);
      } 
      catch (error) {
        return  next(error);
      }
      
      imageName = `${BACKEND_SERVER_PATH}/storage/${imageName}`;
    }
      
    // 3. update blog to database
    try{
      await Blog.updateOne(
        {_id: id},
        {
          title, // we can write in this way, if key: value name are same
          author,
          content,
          image: imageName
        },
        {upsert: true}
      );
    }
    catch(error) {
      return next(error); // send error to errorHandler middleware
    }

    // 4. return response
    return res.status(201).json({message: "blog updated successfully"});
  },
  
  async delete(req, res, next) {
    // validate id
    // delete blog
    // delete comments on this blog

    const validator = Joi.object({
      id: Joi.string().regex(idPattern).required(),
    });

    const { error } = validator.validate(req.params);

    const { id } = req.params;

    // delete blog
    // delete comments
    try {
      await Blog.deleteOne({ _id: id });

      await Comment.deleteMany({ blog: id });
    } catch (error) {
      return next(error);
    }

    return res.status(200).json({ message: "blog deleted" });

  },

}

module.exports = blogController;