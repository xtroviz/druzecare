const Joi = require('joi');
const Newsletter = require('../models/Newsletter');
const NewsletterDTO = require('../dto/newsletter');

const idPattern = /^[0-9a-fA-F]{24}$/;

const newsletterController = {
    
    async index(req, res, next){

        try{
            let newsletters;

            newsletters = await Newsletter.find({});
            let newsletters_count = await Newsletter.countDocuments();
        

            let newslettersDto = [];

            for(let i = 0; i < newsletters.length; i++){
                const obj = new NewsletterDTO(newsletters[i]);
                newslettersDto.push(obj);
            }

            return res.status(200).json({total: newsletters_count, data: newslettersDto});
        }
        catch(error){
            return next(error);
        }
    },

    async create(req, res, next){
        const createNewsletterSchema = Joi.object({
            email: Joi.string().required()
        });

        const {error} = createNewsletterSchema.validate(req.body);

        if (error){
            return next(error);
        }

        const {email} = req.body;
        
        // validate, if email already exist
        const email_in_use = await Newsletter.exists({email});
        if(email_in_use) {
            const error = {
                status: 200,
                message: 'You\'re already subscribed.'
            };
            
            return next(error); // send error to next middleware which is errorHandler in our project
        }

        try{
            const newNewsletter = new Newsletter({
                email
            });

            await newNewsletter.save();
        }
        catch(error){
            return next(error);
        }

        return res.status(201).json({status: '201' ,message: 'Newsletter subscribed successfully.'});
    }
}

module.exports = newsletterController;