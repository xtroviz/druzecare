const express = require('express');
const authController = require('../controller/authController');
const generalController = require('../controller/generalController');
const newsletterController = require('../controller/newsletterController');
const volunteerController = require('../controller/volunteerController');
const contactusController = require('../controller/contactusController');
const userController = require('../controller/userController');
const adminUserController = require('../controller/admin/userController');
const donorRequestController = require('../controller/donorRequestController');
const authentication = require('../middlewares/authentication'); // for validation of refresh and access token
const authorization = require('../middlewares/authorization'); // for validation of user role

// initialize express
const router = express.Router();

// testing endpoint
// router.get('/test', (req, res) => {
//   res.json({msg: 'working'});
// });

//////////
// general
//////////
// countries list
router.get('/countries', generalController.getCountries);
// approval_status list
router.get('/approval-statuses', generalController.getApprovalStatuses);
// users list with filters
router.get('/users', userController.index);

//////////
// contactus Request
//////////
router.post('/contact-us/create', contactusController.create);
router.get('/contact-us', authentication, authorization(['Admin','Super Admin']), contactusController.index );


//////////
// user
//////////
// register
router.post('/register', authController.register);
// login
router.post('/login', authController.login);
// logout 
// add "authentication" auth middleware for validation of refresh and access token (send user details in req on success)
router.post('/logout', authentication, authController.logout);
// refresh
router.post('/refresh', authController.refresh);
// update
router.patch('/user/profile/update', authentication, userController.update);


// login
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password/:token', authController.resetPassword);

//////////
// newsletter
//////////
router.post('/newsletter/create', newsletterController.create);
router.get('/newsletter',authentication, authorization(['Admin','Super Admin']), newsletterController.index);


//////////
// volunteer
//////////
router.post('/volunteer/create', volunteerController.create);
router.get('/volunteer',authentication, authorization(['Admin','Super Admin']), volunteerController.index );
router.patch('/volunteer/status/update', authentication, authorization(['Admin','Super Admin']), volunteerController.updateStatus );


//////////
// donorRequest
//////////
router.post('/donor-request/create', authentication, authorization(['Donor']), donorRequestController.create );
router.get('/donor-request', authentication, donorRequestController.index );
            // authorization(['Admin','Super Admin', 'Recipient']),    
router.patch('/donor-request/status/update', authentication, authorization(['Recipient']), donorRequestController.updateStatus );


//////////
// admin -> user
//////////
router.get('/admin/user/', authentication, authorization(['Admin','Super Admin', 'Muktar']), adminUserController.index );
router.get('/admin/user/:id', authentication, authorization(['Admin','Super Admin', 'Muktar']), adminUserController.view );
router.post('/admin/user/create/', authentication, authorization(['Admin','Super Admin', 'Muktar']), adminUserController.create );
router.put('/admin/user/update/', authentication, authorization(['Admin','Super Admin', 'Muktar']), adminUserController.update );
router.delete('/admin/user/delete/', authentication, authorization(['Admin','Super Admin', 'Muktar']), adminUserController.delete );


//////////
// Mongo blog
//////////

// // create
// router.post('/blog', authentication, blogController.create);
// // list
// router.get('/blog/list', authentication, blogController.index);
// // view
// router.get('/blog/:id', authentication, blogController.view);
// // update
// router.put('/blog', authentication, blogController.update);
// // delete
// router.delete('/blog/:id', authentication, authorization(['Admin','Super Admin']), blogController.delete);




module.exports = router;