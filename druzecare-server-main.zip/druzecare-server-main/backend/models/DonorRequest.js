const mongoose = require('mongoose');

const {Schema} = mongoose;

const donor_request_schema = new Schema({
  recipient_id: {type: mongoose.SchemaTypes.ObjectId, ref: 'User'},  
  donor_id: {type: mongoose.SchemaTypes.ObjectId, ref: 'User'},  
  amount: {type: Number, required: true, default: null},  
  type: {type: String, enum : ['lumpsum','monthly']},  
  approval_status_id: {type: mongoose.SchemaTypes.ObjectId, ref: 'ApprovalStatus'}, 
},
  {timestamps: true}
);

module.exports = mongoose.model('DonorRequest', donor_request_schema, 'donor_requests')  