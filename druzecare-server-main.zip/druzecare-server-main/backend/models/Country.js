const mongoose = require('mongoose');

const {Schema} = require('mongoose');

const country_schema = new Schema({
    name: {type: String, required: true},
    status: {type: String, required: true, default: "1"},
  },
  {timestamp: true}

);

module.exports = mongoose.model('Country', country_schema, 'countries');