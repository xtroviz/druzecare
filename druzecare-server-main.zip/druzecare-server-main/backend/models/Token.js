const mongoose = require('mongoose');

const {Schema} = require('mongoose');

const refresh_token_schema = new Schema({
    token: {type: String, required: true},
    userId: {type: mongoose.SchemaTypes.ObjectId, ref: 'User'},
  },
  {timestamp: true}

);

module.exports = mongoose.model('Token', refresh_token_schema, 'tokens');