const mongoose = require('mongoose');

const {Schema} = mongoose;

const user_schema = new Schema({
  firstname: {type: String, required: true},
  lastname: {type: String, required: true},
  username: {type: String, required: true},  
  email: {type: String, required: false, default: null},  
  password: {type: String, required: true},  
  phone: {type: String, required: false, default: null},  
  country_id: {type: mongoose.SchemaTypes.ObjectId, ref: 'Country'},  
  city: {type: String, required: true},  

  monthly_requested_amount: {type: Number, required: false, default: null},  
  lumpsum_requested_amount: {type: Number, required: false, default: null},  
  story: {type: String, required: false, default: null},  
  story_ar: {type: String, required: false, default: null},  

  role: {type: String, enum : ['Super Admin','Admin', 'Muktar', 'Recipient', 'Donor']},  
  is_visible: {type: Boolean, required: true, default: false},  
  is_active: {type: Boolean, required: true, default: false},  
  is_blocked: {type: Boolean, required: true, default: false},  
  created_by: {type: String, required: false, default: null},  
  is_deleted: {type: Boolean, required: false, default: false},  
},
  {timestamps: true}
);

module.exports = mongoose.model('User', user_schema, 'users')  