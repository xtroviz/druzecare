const mongoose = require('mongoose');

const {Schema} = require('mongoose');

const password_reset_token_schema = new Schema({
    email: {type: String, required: true},
    token: {type: String, required: true},
  },
  {timestamp: true}

);

module.exports = mongoose.model('PasswordResetToken', password_reset_token_schema, 'password_reset_tokens');