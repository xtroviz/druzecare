const mongoose = require('mongoose');

const {Schema} = mongoose;

const volunteer_schema = new Schema({
  name: {type: String, required: true},  
  email: {type: String, required: true},  
  phone: {type: String, required: true},   
  message: {type: String, required: true},   
  approval_status_id: {type: mongoose.SchemaTypes.ObjectId, ref: 'ApprovalStatus'}, 
  is_deleted: {type: Boolean, required: false, default: false},  
},
  {timestamps: true}
);

module.exports = mongoose.model('Volunteer', volunteer_schema, 'volunteers')  