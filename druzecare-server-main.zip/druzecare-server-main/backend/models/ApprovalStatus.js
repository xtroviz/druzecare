const mongoose = require('mongoose');

const {Schema} = require('mongoose');

const approval_status_schema = new Schema({
    name: {type: String, required: true},
  },
  {timestamp: true}

);

module.exports = mongoose.model('ApprovalStatus', approval_status_schema, 'approval_statuses');