const jwt = require('jsonwebtoken');
const {ACCESS_TOKEN_SECRET, REFRESH_TOKEN_SECRET, PASSWORD_RESET_TOKEN_SECRET} = require('../config/index');
const Token = require('../models/Token');
const PasswordResetToken = require('../models/PasswordResetToken');

class JWTService{
  // sign access token
  static signAccessToken(payload, expiryTime, secret = ACCESS_TOKEN_SECRET) {
    return jwt.sign(payload, secret, {expiresIn: expiryTime});
  }
  // sign refresh token
  static signRefreshToken(payload, expiryTime, secret = REFRESH_TOKEN_SECRET) {
    return jwt.sign(payload, secret, {expiresIn: expiryTime});
  }
  // sign password reset token
  static signPasswordResetToken(payload, expiryTime, secret = PASSWORD_RESET_TOKEN_SECRET) {
    return jwt.sign(payload, secret, {expiresIn: expiryTime});
  }
  // verify access token
  static verifyAccessToken(token, secret = ACCESS_TOKEN_SECRET) {
    return jwt.verify(token, secret); // it will return a payload of token
  }
  // verify refresh token
  static verifyRefreshToken(token, secret = REFRESH_TOKEN_SECRET) {
    return jwt.verify(token, secret);
  }
  // verify refresh token
  static verifyPasswordResetToken(token, secret = PASSWORD_RESET_TOKEN_SECRET) {
    return jwt.verify(token, secret);
  }
  // store refresh token
  static async storeRefreshToken(token, userId) {
    try{
      const newToken = new Token ({
        token: token,
        userId: userId
      });

      // store in db
      await newToken.save();
    }
    catch(error){
      console.log(error);
    }
  }
  // store Password Reset token
  static async storePasswordResetToken(email, token) {
    try{
      const newToken = new PasswordResetToken ({
        email: email,
        token: token
      });

      // store in db
      await newToken.save();
    }
    catch(error){
      console.log(error);
    }
  }
}

module.exports = JWTService;