const {ValidationError} = require('joi');

const errorHandler = (error, req, res, next) => {
  //default error status and message
  let status = 500;
  let data = {
    message: 'Internal Server Error',
  }

  // this block will handle all errors comes from JOI side
  if(error instanceof ValidationError) { // instanceof define the type of object (if type of error object is validationError)
    status = 400;
    data.message = error.message;

    return res.status(status).json(data);
  }

  // if error is not validation error (Joi error), then this block will handle 
  // console.log(error);
  if(error !== undefined) {
    if(error.status)
      status = error.status;
    if(error.message)
      data.message = error.message;
  }

  if(res !== undefined) 
    return res.status(status).json(data);
  else
    return data;
};

module.exports = errorHandler;