// middleware for the validation of refresh and access token
// it will check that the request have a valid access and refresh token
const JWTService = require('../services/JWTService');
const User = require('../models/User');
const UserDTO = require('../dto/user');

const authenticate = async (req, res, next) => {
  try {

    // validation of refresh and access token
    const {accessToken} = req.cookies;
    // const {refreshToken, accessToken} = req.cookies;
    // const authHeader = req.headers['authorization'];
    // const accessToken = authHeader && authHeader.split(" ")[1];
    
    if(!accessToken) {
    // if(!refreshToken || !accessToken) {
      const error = {
        status: 401,
        message: 'Unauthorized1'
      };

      return next(error); // send error to errorHandler middleware
    }
    
    let _id;
    
    // it return payload of token
    // at the time of signAccessToken() in register and login function we send user id as payload
    // if verifyAccessToken() return _id as payload it means the accessToken which comes in req is valid
    _id = JWTService.verifyAccessToken(accessToken)._id;  

    let user;


    user = await User.findOne({_id: _id});  

    if(!user) {
      const error = {
        status: 401,
        message: 'UnAuthorized2',
      };
      return next(error); // send error to errorHandler middleware
    }

    
    // Data Transfer Object (DTO) -> return data in what format
    // which fields should return in the response
    // define the shape of output response
    const userDTO = new UserDTO(user); // send user object User DTO to get only useful fields, to return in response


    // send user details in req of a route which use this middleware
    req.user = userDTO;

    // call next middleware
    next();
  } 
  catch (error) {
    return next(error); // send error to errorHandler middleware
  }
}

module.exports = authenticate;