// middleware for the validation of user role
// it will check that the request have a valid access and refresh token
const User = require('../models/User');
const UserDTO = require('../dto/user');

const authorization = (roles) => async (req, res, next) => {
  try {
    // validation of user role
    if(!roles.includes(req.user.role)) {
      const error = {
        status: 401,
        message: 'Unauthorized3'
      };

      return next(error); // send error to errorHandler middleware
    }

    // call next middleware
    next();
  } 
  catch (error) {
    return next(error); // send error to errorHandler middleware
  }
}

module.exports = authorization;