class PasswordResetTokenDTO{
    constructor(password_reset_token){
        this._id = password_reset_token._id;
        this.email = password_reset_token.email;
        this.token = password_reset_token.token;
    }
}

module.exports = PasswordResetTokenDTO;
