// Data Transfer Object (DTO) -> return data in what format
// which fields of blog object should return in the response
// define the shape of output response
class BlogDetailsDTO {
  constructor(blog) {
    this._id = blog._id;
    this.title = blog.title;
    this.content = blog.content;
    this.image = blog.image;
    this.created_at = blog.created_at;
    this.updatedAt = blog.updatedAt;
    this.authorId = blog.author.id;
    this.authorName = blog.author.name;
    this.authorUsername = blog.author.username;
    this.authorEmail = blog.author.email;
  }
}


module.exports = BlogDetailsDTO;