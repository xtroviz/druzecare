class DonorRequestDTO{
    constructor(donor_request){
        this._id = donor_request._id;
        this.recipient_id = donor_request.recipient_id;
        this.donor_id = donor_request.donor_id;
        this.donor_country = donor_request.donor_id.country_id.name;
        this.username = donor_request.username;
        this.donor_fullname = donor_request.donor_id.firstname + " " + donor_request.donor_id.lastname;
        this.amount = donor_request.amount;
        this.type = donor_request.type;
        this.approval_status_id = donor_request.approval_status_id._id;
        this.approval_status_name = donor_request.approval_status_id.name;
    }
}

module.exports = DonorRequestDTO;
