class RoleDTO{
    constructor(role){
        this._id = role._id;
        this.name = role.name;
    }
}

module.exports = RoleDTO;
