class CountryDTO{
    constructor(country){
        this._id = country._id;
        this.name = country.name;
        this.status = country.status;
    }
}

module.exports = CountryDTO;
