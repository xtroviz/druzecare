// Data Transfer Object (DTO) -> return data in what format
// which fields of volunteer object should return in the response
// define the shape of output response
class VolunteerDTO {
  constructor(volunteer) {
    this._id = volunteer._id;
    this.name = volunteer.name;
    this.email = volunteer.email;
    this.phone = volunteer.phone;
    this.message = volunteer.message;
    this.approval_status_id = volunteer.approval_status_id._id;
    this.approval_status_name = volunteer.approval_status_id.name;
    this.is_deleted = volunteer.is_deleted;
    this.created_at = volunteer.createdAt;
  }
}

module.exports = VolunteerDTO;