class CommentDTO{
    constructor(comment){
        this._id = comment._id;
        this.created_at = comment.created_at;
        this.content = comment.content;
        this.authorUsername = comment.author.username;
    }
}

module.exports = CommentDTO;
