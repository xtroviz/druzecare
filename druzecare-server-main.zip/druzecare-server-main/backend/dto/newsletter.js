// Data Transfer Object (DTO) -> return data in what format
// which fields of newsletter object should return in the response
// define the shape of output response
class NewsletterDTO {
  constructor(newsletter) {
    this._id = newsletter._id;
    this.email = newsletter.email;
    this.created_at = newsletter.createdAt;
  }
}

module.exports = NewsletterDTO;