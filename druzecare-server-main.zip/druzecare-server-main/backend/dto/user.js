// Data Transfer Object (DTO) -> return data in what format
// which fields of user object should return in the response
// define the shape of output response
class UserDTO {
  constructor(user) {
    this._id = user._id;
    this.username = user.username;
    this.firstname = user.firstname;
    this.lastname = user.lastname;
    this.email = user.email;
    this.phone = user.phone;
    this.country_id = user.country_id._id;
    this.country_name = user.country_id.name;
    this.city = user.city;

    this.monthly_requested_amount = user.monthly_requested_amount;
    this.lumpsum_requested_amount = user.lumpsum_requested_amount;
    this.story = user.story;
    this.story_ar = user.story_ar;

    this.role = user.role;
    this.is_visible = user.is_visible;
    this.is_active = user.is_active;
    this.is_blocked = user.is_blocked;
    this.created_by = user.created_by;
    this.is_deleted = user.is_deleted;
    this.created_at = user.createdAt;
  }
}

module.exports = UserDTO;