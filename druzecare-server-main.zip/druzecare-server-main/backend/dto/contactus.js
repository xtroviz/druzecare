// Data Transfer Object (DTO) -> return data in what format
// which fields of volunteer object should return in the response
// define the shape of output response
class contactusDTO {
    constructor(contactus) {
      this._id = contactus._id;
      this.name = contactus.name;
      this.email = contactus.email;
      this.email = contactus.email;
      this.address = contactus.address;
      this.message = contactus.message;
      this.is_deleted = contactus.is_deleted;
      this.created_at = contactus.createdAt;
    }
  }
  
  module.exports = contactusDTO;