class approvalStatusDTO{
    constructor(approval_status){
        this._id = approval_status._id;
        this.name = approval_status.name;
    }
}

module.exports = approvalStatusDTO;
