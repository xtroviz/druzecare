// Data Transfer Object (DTO) -> return data in what format
// which fields of blog object should return in the response
// define the shape of output response
class BlogDTO {
  constructor(blog) {
    this._id = blog._id;
    this.title = blog.title;
    this.content = blog.content;
    this.image = blog.image;
    this.author = blog.author;
    this.created_at = blog.created_at;
    this.updatedAt = blog.updatedAt;
  }
}


module.exports = BlogDTO;