// getting-started.js
const mongoose = require('mongoose');
const {CONNECTION_STRING} = require('../config/index'); // using destructuring
// const config = require('../config/index'); // without using destructuring config.CONNECTION_STRING

// const conn_string = CONNECTION_STRING;

const db_conn = async () => {
  try {
    const conn = await mongoose.connect(CONNECTION_STRING);
    console.log(`Database connected to ${conn.connection.host}`.green.inverse);
  }
  catch(error) {
    console.log(`Error: ${error}`.red.inverse);
  }
};

module.exports = db_conn;
