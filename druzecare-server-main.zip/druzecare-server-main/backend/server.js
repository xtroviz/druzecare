const express = require('express');
const colors = require('colors');
const db_conn = require('./database/index');
const router = require('./routes/index'); 
const {PORT} = require('./config/index'); // using destructuring
// const config = require('./config/index'); // without using destructuring config.PORT
const morgan = require('morgan');
const errorHandler = require('./middlewares/errorHandler');
const cookieParser = require('cookie-parser');
const cors = require("cors");


//////////////////////
// initialize express
//////////////////////
const app = express();


//////////////////////
// cookie-parser middleware for cookie based authentication
//////////////////////
app.use(cookieParser());



//////////////////////
// CORS middleware 
//////////////////////
// const corsOptions = {
//   credentials: true,
//   origin: ["http://localhost:3000"],
// };

// app.use(cors(corsOptions));

app.use(
  cors({
    origin: function (origin, callback) { // give frontend path in origin
      return callback(null, true);
    },
    optionsSuccessStatus: 200, // set status for success
    credentials: true, // because we use cookies
  })
);

//////////////////////
// express.json is a middleware
// allow our application to communicate in json format
//////////////////////
app.use(express.json({limit: '50mb'}));


//////////////////////
// define api routes
//////////////////////
app.use(router);


//////////////////////
// establish database connection
//////////////////////

db_conn();


//////////////////////
// make static storage to access media
//////////////////////
app.use('/storage', express.static('storage'));


//////////////////////
// define error handling middleware
//////////////////////
app.use(errorHandler);


//////////////////////
// set views folder name
//////////////////////
// by default express take view files from views folder, we can change its path using app.set('views', 'view_folder_path') 
// app.set('views', 'myviews');


//////////////////////
// register view engine
//////////////////////
// app.set('view engine', 'ejs');


//////////////////////
// listen for request
//////////////////////
// app.listen(port_no, optional_callback_function)
app.listen(PORT);
// app.listen(PORT, 'localhost', () => {
//     console.log(`listening for request on port:${port}`);
// });


//////////////////////
// set public folder as default
//////////////////////
// https://expressjs.com/en/starter/static-files.html
// app.use(express.static('public'));


//////////////////////
// to display proper logs in terminal 
//////////////////////
app.use(morgan('dev'));
// combined - This sets your logs to the Apache standard combined format
// common - Refers to the Apache common format standard
// dev - A color-coded log format (based on request status)
// short - Less than the normal format, with only a few items you'd expect to see in a request logline
// tiny - Even less, simply the reaction time and a few extras


//////////////////////
// define routes
//////////////////////

// app.get('/', (req, res) => {
//   // res.json({msg : "Hello, world!"});
//     // res.send('helo home express');
//     // res.sendFile('./views/index.html', { root: __dirname});
//     const blogs = [
//         {title: 'blog1', description: 'blog1 description'},
//         {title: 'blog2', description: 'blog2 description'},
//         {title: 'blog3', description: 'blog3 description'},
//     ];
//     res.render('index', {title: 'Home', blogs});
// });

// app.get('/about', (req, res) => {
//     // res.send('helo about');
//     // res.sendFile('./views/about.html', { root: __dirname});
//     res.render('about', {title: 'About Us'});
// });

// app.get('/about-us', (req, res) => {
//     res.redirect('/about');
// });

// app.get('/contact', (req, res) => {
//     // res.send('helo contact');
//     // res.sendFile('./views/contact.html', { root: __dirname});
//     res.render('contact', {title: 'contact Us'});
// });

// app.get('/index3', (req, res) => {
//     // res.send('helo index3');
//     // res.sendFile('./views/index3.html', { root: __dirname});
//     res.render('index3', {title: 'index3 Us'});
// });

// app.get('/index31', (req, res) => {
//     // res.send('helo index31');
//     // res.sendFile('./views/index31.html', { root: __dirname});
//     res.render('index31', {title: 'index31 Us'});
// });

// app.get('/blog/create', (req, res) => {
//     res.render('blog_create', {title: 'Create Blog'});
// });

// // 404 page (must be on bottom of the page)
// app.use((req, res) => {
//     // res.status(404).sendFile('./views/404.html', { root: __dirname});
//     res.status(404).render('404', {title: '404'});
// });

 