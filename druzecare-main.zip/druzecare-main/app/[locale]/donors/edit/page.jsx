'use client';
import React from 'react';
import EditUser from '@/components/UsersTable/EditUser';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';

function page() {
  return (
    <DefaultDashboardLayout>
      <EditUser record="edit_donor" />;
    </DefaultDashboardLayout>
  );
}

export default page;
