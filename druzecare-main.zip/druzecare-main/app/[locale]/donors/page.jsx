'use client';
import React from 'react';
import UsersTable from '@/components/UsersTable/Users';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';

function page() {
  return (
    <DefaultDashboardLayout>
      <UsersTable
        Heading="Donors"
        redirectLink="donors"
        filterLink="Donor"
        record="edit_donor"
      />
    </DefaultDashboardLayout>
  );
}

export default page;
