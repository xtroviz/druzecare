import getTranslation from '@/lib/i18n/getTranslation';
import HomeBanner from '../../components/Home/HomeBanner';
import HomeSection2 from '../../components/Home/HomeSection2';
import HomeSection3 from '../../components/Home/HomeSection3';
import HomeSection4 from '../../components/Home/HomeSection4';
import HomeSection5 from '../../components/Home/HomeSection5';
import HomeSection6 from '../../components/Home/HomeSection6';
import HomeSection7 from '../../components/Home/HomeSection7';
// import HomeSection8 from '../../components/Home/HomeSection8';
import HomeSection9 from '../../components/Home/HomeSection9';
import HomeSection10 from '../../components/Home/HomeSection10';
import DefaultLayout from '@/components/Layouts/DefaultLayout';

export default async function Page({ params }) {
  const translation = await getTranslation(params.locale);
  const translations = {
    howWeHelp: translation('views.main.how-we-help'),
    joinCommunity: translation('views.main.join-the-community'),
    joinCommunityDesc1: translation('views.main.join-the-community-desc-1'),
    donateNow: translation('views.main.donate-now'),
    becomeVolunteer: translation('views.main.become-a-volunteer'),
    submit: translation('views.main.submit'),
  };

  return (
    <DefaultLayout params={params}>
      <HomeBanner params={params} />
      <HomeSection2 translation={translation} />
      <HomeSection3 translation={translation} />
      {/* <HomeSection4 params={params} /> */}
      <HomeSection5 translations={translations} />
      <HomeSection6 translation={translation} />
      <HomeSection7 translation={translation} />
      {/* <HomeSection8 translation={translation} /> */}
      <HomeSection9
        translation={translation}
        main_heading={translation('views.main.team')}
        secondary_heading={translation('views.main.meet-our-volunteers')}
      />
      <HomeSection10 translation={translation} />
    </DefaultLayout>
  );
}
