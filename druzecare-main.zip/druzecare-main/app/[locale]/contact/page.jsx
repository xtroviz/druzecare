import React from 'react';
import ContactSection1 from '@/components/contact/ContactSection1';
import AboutSection4 from '@/components/About/AboutSection4';
import getTranslation from '@/lib/i18n/getTranslation';
import Banner from '@/components/common/Banner';
import bannerImage from '@/public/main-banner.png';
import DefaultLayout from '@/components/Layouts/DefaultLayout';

async function Page({ params }) {
  const translation = await getTranslation(params.locale);

  return (
    <DefaultLayout params={params}>
      <Banner
        image={bannerImage}
        heading={translation('views.main.contact-banner')}
        sub_heading={translation('views.main.get-in-touch-banner')}
      />
      <ContactSection1 translation={translation} />
      <AboutSection4 translation={translation} />
    </DefaultLayout>
  );
}

export default Page;
