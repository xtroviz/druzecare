'use client';
import React from 'react';
import DataTable from 'react-data-table-component';
import { useState, useEffect } from 'react';
import axios from 'axios';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import Cookies from 'js-cookie';

function Page() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);
  const currentUser = JSON.parse(Cookies.get('currentUser')).user;

  const fetchRequests = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/donor-request?donor_id=${currentUser._id}&page=1&limit=10&sort_by=created_at&order=desc`;

    axios
      .get(url, { withCredentials: true })
      .then((response) => {
        setData(response.data.data);
        setTotalRows(response.data.total);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handlePageChange = (page) => {
    fetchRequests(page);
  };

  const columns = [
    {
      name: 'Amount',
      selector: (row) => row.amount,
      sortable: true,
    },
    {
      name: 'Type',
      selector: (row) => row.type,
      sortable: true,
    },
    {
      name: 'Status',
      selector: (row) => row.approval_status_name,
      sortable: true,
    },
  ];

  useEffect(() => {
    fetchRequests(1);
  }, []);

  return (
    <DefaultDashboardLayout>
      <DataTable
        title="Requested Recipients"
        columns={columns}
        data={data}
        progressPending={loading}
        pagination
        paginationServer
        paginationTotalRows={totalRows}
        onChangePage={handlePageChange}
      />
    </DefaultDashboardLayout>
  );
}

export default Page;
