'use client';
import React from 'react';
import UsersTable from '@/components/UsersTable/Users';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';

function page() {
  return (
    <DefaultDashboardLayout>
      <UsersTable
        Heading="Admins"
        redirectLink="admins"
        filterLink="Admin"
        record="edit_admin"
      />
    </DefaultDashboardLayout>
  );
}

export default page;
