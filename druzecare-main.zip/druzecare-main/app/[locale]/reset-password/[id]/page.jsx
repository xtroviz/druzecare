'use client';
import React from 'react';
import { FaLock } from 'react-icons/fa';
import axios from 'axios';
import Cookies from 'js-cookie';
import Swal from 'sweetalert2';

function Reset({ params }) {
  const handleReset = (e) => {
    e.preventDefault();

    axios
      .post(
        `http://localhost:5000/reset-password/${params.id}`,
        {
          password: e.target.password.value,
          confirm_password: e.target.confirm_password.value,
        },
        {
          withCredentials: true,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
          },
        }
      )
      .then((res) => {
        Swal.mixin({
          toast: true,
          icon: 'success',
          title: 'General Title',
          animation: true,
          position: 'top-right',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
          },
        }).fire({
          animation: true,
          title: 'Password Reset Successfully.',
        });
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        Swal.mixin({
          toast: true,
          icon: 'success',
          title: 'General Title',
          animation: true,
          position: 'top-right',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
          },
        }).fire({
          icon: 'error',
          animation: true,
          title: 'Error while reseting your password, please try again.',
        });
      });
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
      <div className="login-shadow w-full space-y-8 rounded-2xl p-8 sm:w-2/3 sm:p-12 md:w-2/3 lg:w-2/5 lg:p-14 xl:w-1/3">
        <div className="__className_c8bfae text-color">
          <h2 className="mt-6 text-center text-3xl font-bold text-gray-900">
            PASSWORD RESET
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleReset}>
          <div className="-space-y-px rounded-md shadow-sm">
            <div className="mb-4">
              <label htmlFor="password" className="sr-only">
                Password
              </label>
              <div className="relative">
                <FaLock className="absolute left-3 top-1/2 z-20 -translate-y-1/2 transform text-gray-400" />
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  className="relative block w-full appearance-none rounded-none rounded-b-md border border-gray-300 px-5 py-4 pl-10 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                  placeholder="**********"
                />
              </div>
            </div>
            <div>
              <label htmlFor="confirm_password" className="sr-only">
                Confirm Password
              </label>
              <div className="relative">
                <FaLock className="absolute left-3 top-1/2 z-20 -translate-y-1/2 transform text-gray-400" />
                <input
                  id="confirm_password"
                  name="confirm_password"
                  type="password"
                  required
                  className="relative block w-full appearance-none rounded-none rounded-b-md border border-gray-300 px-5 py-4 pl-10 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                  placeholder="**********"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <button
              type="submit"
              className="bgBlack flex rounded-full px-20 py-4 font-semibold text-white"
            >
              RESET PASSWORD
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Reset;
