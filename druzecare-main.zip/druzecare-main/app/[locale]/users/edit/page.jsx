'use client';
import React from 'react';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import EditUser from '@/components/UsersTable/EditUser';

function page() {
  return (
    <DefaultDashboardLayout>
      <EditUser record="edit_user" />;
    </DefaultDashboardLayout>
  );
}

export default page;
