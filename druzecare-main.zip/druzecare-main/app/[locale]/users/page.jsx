'use client';
import React from 'react';
import UsersTable from '@/components/UsersTable/Users';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';

function page() {
  return (
    <DefaultDashboardLayout>
      <UsersTable
        Heading="Users"
        redirectLink="users"
        filterLink=""
        record="edit_user"
      />
    </DefaultDashboardLayout>
  );
}

export default page;
