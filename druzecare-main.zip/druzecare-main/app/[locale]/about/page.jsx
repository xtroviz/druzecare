import React from 'react';
import AboutSection1 from '@/components/About/AboutSection1';
import AboutSection2 from '@/components/About/AboutSection2';
import AboutSection3 from '@/components/About/AboutSection3';
import AboutSection4 from '@/components/About/AboutSection4';
import getTranslation from '@/lib/i18n/getTranslation';
import HomeSection9 from '@/components/Home/HomeSection9';
import Banner from '@/components/common/Banner';
import bannerImage from '@/public/main-banner.png';
import DefaultLayout from '@/components/Layouts/DefaultLayout';

async function Page({ params }) {
  const translation = await getTranslation(params.locale);

  return (
    <DefaultLayout params={params}>
      <Banner
        image={bannerImage}
        heading={translation('views.main.what-we-do')}
        sub_heading={translation('views.main.about-our')}
        sub_heading2={translation('views.main.organization')}
      />
      <AboutSection1 translation={translation} />
      <AboutSection2 />
      <AboutSection3 translation={translation} />
      <HomeSection9
        translation={translation}
        main_heading={translation('views.main.our-donors')}
        secondary_heading={translation('views.main.connect-to-donors')}
      />
      <AboutSection4 translation={translation} />
    </DefaultLayout>
  );
}

export default Page;
