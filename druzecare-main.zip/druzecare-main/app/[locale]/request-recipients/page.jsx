import React from 'react';

const page = () => {
  return (
    <div>
      <h1>Request Recipients</h1>
    </div>
  );
};

export default page;
