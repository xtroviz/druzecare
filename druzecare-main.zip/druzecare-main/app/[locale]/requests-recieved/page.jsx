'use client';
import React from 'react';
import DataTable from 'react-data-table-component';
import { useState, useEffect } from 'react';
import axios from 'axios';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import Cookies from 'js-cookie';
import Swal from 'sweetalert2';

function Page() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);
  const currentUser = JSON.parse(Cookies.get('currentUser')).user;
  const approvalStatus = [
    {
      _id: '661ea01bfb424ef3c6f74cdc',
      name: 'Pending',
    },
    {
      _id: '661ea01bfb424ef3c6f74cdd',
      name: 'Accepted',
    },
    {
      _id: '661ea01bfb424ef3c6f74cde',
      name: 'Rejected',
    },
  ];
  var toa;
  var toast = Swal.mixin({
    toast: true,
    icon: 'success',
    title: 'General Title',
    animation: true,
    position: 'top-right',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    },
  });

  const fetchRequests = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/donor-request?recipient_id=${currentUser._id}&page=1&limit=10&sort_by=created_at&order=desc`;

    axios
      .get(url, { withCredentials: true })
      .then((response) => {
        setData(response.data.data);
        setTotalRows(response.data.total);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handleUpdateStatus = (_id, approval_status_id) => {
    setLoading(true);
    const url = `http://localhost:5000/donor-request/status/update`;

    axios
      .patch(
        url,
        {
          _id,
          approval_status_id,
        },
        {
          withCredentials: true,
          headers: {
            'Content-Type': 'application/json',
          },
        }
      )
      .then((response) => {
        toast.fire({
          animation: true,
          title: response.data.message,
        });
        fetchRequests();
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        toast.fire({
          icon: 'error',
          animation: true,
          title: err?.response?.data?.message,
        });
      });
  };

  const handlePageChange = (page) => {
    fetchRequests(page);
  };

  const columns = [
    {
      name: 'Amount',
      selector: (row) => row.amount,
      sortable: true,
    },
    {
      name: 'Type',
      selector: (row) => row.type,
      sortable: true,
    },
    {
      name: 'Status',
      selector: (row) => (
        <select
          className={`block w-full appearance-none  px-4 py-3 pr-8 text-white focus:outline-none ${
            row.approval_status_name === 'Pending'
              ? 'bg-orange-400'
              : row.approval_status_name === 'Accepted'
                ? 'bg-green-400'
                : row.approval_status_name === 'Rejected'
                  ? 'bg-red-400'
                  : ''
          }`}
          onChange={(e) =>
            handleUpdateStatus(
              row._id,
              e.target.options[e.target.selectedIndex].id
            )
          }
        >
          {approvalStatus.map((el) => (
            <option
              key={el._id}
              id={el._id}
              selected={el._id === row.approval_status_id}
            >
              {el.name}
            </option>
          ))}
        </select>
      ),
      sortable: true,
    },
  ];

  useEffect(() => {
    fetchRequests(1);
  }, []);

  return (
    <DefaultDashboardLayout>
      <DataTable
        title="Requests Recieved"
        columns={columns}
        data={data}
        progressPending={loading}
        pagination
        paginationServer
        paginationTotalRows={totalRows}
        onChangePage={handlePageChange}
      />
    </DefaultDashboardLayout>
  );
}

export default Page;
