'use client';
import React, { useState, useEffect, useRef } from 'react';
import DataTable from 'react-data-table-component';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import axios from 'axios';
import Cookies from 'js-cookie';

function Page() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);
  const currentUser = JSON.parse(Cookies.get('currentUser')).user;
  const [selectedRecipient, setSelectedRecipient] = useState(null);
  const [showRecipientModal, setShowRecipientModal] = useState(false);

  const recipientModalRef = useRef(null);

  const fetchRequests = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/donor-request?donor_id=${currentUser._id}&page=1&limit=10&sort_by=created_at&order=desc&approval_status_id=65f6c504c487a75260fd8b12`;

    axios
      .get(url, { withCredentials: true })
      .then((response) => {
        setData(response.data.data);
        setTotalRows(response.data.total);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handlePageChange = (page) => {
    fetchRequests(page);
  };

  const handleShowRecipientDetails = (rowData) => {
    setSelectedRecipient(rowData.recipient_id);
    setShowRecipientModal(true);
  };

  const columns = [
    {
      name: 'Amount',
      selector: (row) => row.amount,
      sortable: true,
    },
    {
      name: 'Type',
      selector: (row) => row.type,
      sortable: true,
    },
    {
      name: 'Status',
      selector: (row) => row.approval_status_name,
      sortable: true,
    },
    {
      name: 'Action',
      cell: (row) => (
        <button
          className="font-extrabold underline underline-offset-4"
          onClick={() => handleShowRecipientDetails(row)}
        >
          View Details
        </button>
      ),
      sortable: false,
    },
  ];

  useEffect(() => {
    fetchRequests(1);
  }, []);

  return (
    <DefaultDashboardLayout>
      <DataTable
        title="Requests Accepted"
        columns={columns}
        data={data}
        progressPending={loading}
        pagination
        paginationServer
        paginationTotalRows={totalRows}
        onChangePage={handlePageChange}
      />

      {showRecipientModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black bg-opacity-50">
          <div
            ref={recipientModalRef}
            className="mx-4 my-8 w-full max-w-md rounded-lg bg-white p-8"
          >
            <h1 className="mb-4 text-lg font-bold">Recipient Details</h1>
            <div className="mb-4">
              <p>
                <strong>Name:</strong> {selectedRecipient.firstname}{' '}
                {selectedRecipient.lastname}
              </p>
              <p>
                <strong>Email:</strong> {selectedRecipient.email}
              </p>
              <p>
                <strong>Phone:</strong> {selectedRecipient.phone}
              </p>
              <p>
                <strong>Country:</strong> {selectedRecipient.country_name}
              </p>
              <p>
                <strong>City:</strong> {selectedRecipient.city}
              </p>
              <p>
                <strong>Story:</strong> {selectedRecipient.story}
              </p>
            </div>
            <button
              className="mt-4 rounded-lg bg-red-500 px-4 py-2 text-white"
              onClick={() => setShowRecipientModal(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </DefaultDashboardLayout>
  );
}

export default Page;
