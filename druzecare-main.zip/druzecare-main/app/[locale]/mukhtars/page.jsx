'use client';
import React from 'react';
import UsersTable from '@/components/UsersTable/Users';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';

function page() {
  return (
    <DefaultDashboardLayout>
      <UsersTable
        Heading="Mukhtars"
        redirectLink="mukhtars"
        filterLink="Mukhtar"
        record="edit_mukhtar"
      />
    </DefaultDashboardLayout>
  );
}

export default page;
