import React from 'react';
import DefaultLayout from '@/components/Layouts/DefaultLayout';
import Explore from '@/components/common/Explore';
import getTranslation from '@/lib/i18n/getTranslation';

async function Page({ params }) {
  const translation = await getTranslation(params.locale);
  const translations = {
    showStory: translation('views.main.show-story'),
    story: translation('views.main.story'),
    connectNow: translation('views.main.connect-now'),
    close: translation('views.main.close'),
    amount: translation('views.main.amount'),
    type: translation('views.main.type'),
    submit: translation('views.main.submitm'),
    laoding: translation('views.main.loading'),
  };

  return (
    <DefaultLayout params={params}>
      <Explore translations={translations} params={params} />
    </DefaultLayout>
  );
}

export default Page;
