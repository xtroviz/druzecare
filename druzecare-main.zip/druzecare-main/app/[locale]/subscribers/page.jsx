'use client';
import React from 'react';
import DataTable from 'react-data-table-component';
import { useState, useEffect } from 'react';
import axios from 'axios';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import Cookies from 'js-cookie';

const columns = [
  {
    name: 'Email',
    selector: (row) => row.email,
    sortable: true,
  },
];

function Page() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);

  const fetchUsers = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/newsletter`;

    axios
      .get(url, {
        withCredentials: true,
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setData(response.data.data);
        setTotalRows(response.data.total);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handlePageChange = (page) => {
    fetchUsers(page);
  };

  useEffect(() => {
    fetchUsers(1);
  }, []);

  return (
    <DefaultDashboardLayout>
      <DataTable
        title="Newsletter"
        columns={columns}
        data={data}
        progressPending={loading}
        pagination
        paginationServer
        paginationTotalRows={totalRows}
        onChangePage={handlePageChange}
      />
    </DefaultDashboardLayout>
  );
}

export default Page;
