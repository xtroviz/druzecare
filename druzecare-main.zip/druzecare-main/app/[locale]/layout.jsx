import '@/app/globals.css';
import { i18nConfig } from '@/i18n';
import { Work_Sans } from 'next/font/google';
import StoreProvider from '../StoreProvider';
import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';

export async function generateStaticParams() {
  return i18nConfig.locales.map((locale) => ({ locale: locale }));
}

const workSans = Work_Sans({
  subsets: ['latin'],
  display: 'swap',
  adjustFontFallback: false,
});

export const metadata = {
  title: 'Druze Care',
  description: 'Druze Care',
};

export const navPermissions = {
  superadmin: [
    'dashboard',
    'admins',
    'mukhtars',
    'donors',
    'recipients',
    'users',
    'subscribers',
    'volunteers',
  ],
  admin: ['dashboard', 'mukhtars', 'donors', 'recipients', 'users'],
  mukhtar: ['dashboard', 'recipients'],
  donor: ['dashboard', 'profile', 'requested-recipients', 'accepted-requests'],
  recipient: ['dashboard', 'profile', 'requests-recieved', 'requests-accepted'],
};

export const protectedRoutes = [
  'dashboard',
  'admins',
  'mukhtars',
  'donors',
  'recipients',
  'users',
  'subscribers',
  'volunteers',
  'profile',
  'requested-recipients',
  'requests-recieved',
  'requests-accepted',
  'accepted-requests',
];

export default async function RootLayout({ children, params }) {
  const cookieStore = cookies();
  const userRole = cookieStore
    .get('role')
    ?.value?.toLowerCase()
    .replace(' ', '');
  const currentRoute = children.props.childProp.segment;

  if (!userRole && protectedRoutes.includes(currentRoute)) redirect('/login');

  return (
    <StoreProvider>
      <html dir={params.locale === 'en' ? 'ltr' : 'rtl'} lang={params.locale}>
        <body>
          {!navPermissions[userRole]?.includes(currentRoute) &&
          protectedRoutes.includes(currentRoute) ? (
            redirect('/404')
          ) : (
            <main>{children}</main>
          )}
        </body>
      </html>
    </StoreProvider>
  );
}
