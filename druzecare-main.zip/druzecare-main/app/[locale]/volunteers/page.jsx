'use client';
import React from 'react';
import DataTable from 'react-data-table-component';
import { useState, useEffect } from 'react';
import axios from 'axios';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import Swal from 'sweetalert2';
import Cookies from 'js-cookie';

function Page() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);
  const approvalStatus = [
    {
      _id: '661ea01bfb424ef3c6f74cdc',
      name: 'Pending',
    },
    {
      _id: '661ea01bfb424ef3c6f74cdd',
      name: 'Accepted',
    },
    {
      _id: '661ea01bfb424ef3c6f74cde',
      name: 'Rejected',
    },
  ];
  var toast = Swal.mixin({
    toast: true,
    icon: 'success',
    title: 'General Title',
    animation: true,
    position: 'top-right',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    },
  });

  const fetchUsers = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/volunteer`;

    axios
      .get(url, {
        withCredentials: true,
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setData(response.data.data);
        setTotalRows(response.data.total);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handleUpdateStatus = (_id, approval_status_id) => {
    setLoading(true);
    const url = `http://localhost:5000/volunteer/status/update`;

    axios
      .patch(
        url,
        {
          _id,
          approval_status_id,
        },
        {
          withCredentials: true,
          headers: {
            'Content-Type': 'application/json',
          },
        }
      )
      .then((response) => {
        toast.fire({
          animation: true,
          title: response.data.message,
        });
        fetchUsers();
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        toast.fire({
          icon: 'error',
          animation: true,
          title: err.message,
        });
      });
  };

  const columns = [
    {
      name: 'Name',
      selector: (row) => row.name,
      sortable: true,
    },
    {
      name: 'Email',
      selector: (row) => row.email,
      sortable: true,
    },
    {
      name: 'Phone',
      selector: (row) => row.phone,
      sortable: true,
    },
    {
      name: 'Status',
      selector: (row) => (
        <select
          className={`block w-full appearance-none  px-4 py-3 pr-8 text-white focus:outline-none ${
            row.approval_status_name === 'Pending'
              ? 'bg-orange-400'
              : row.approval_status_name === 'Accepted'
                ? 'bg-green-400'
                : row.approval_status_name === 'Rejected'
                  ? 'bg-red-400'
                  : ''
          }`}
          onChange={(e) =>
            handleUpdateStatus(
              row._id,
              e.target.options[e.target.selectedIndex].id
            )
          }
        >
          {approvalStatus.map((el) => (
            <option
              key={el._id}
              id={el._id}
              selected={el._id === row.approval_status_id}
            >
              {el.name}
            </option>
          ))}
        </select>
      ),
    },
  ];

  const handlePageChange = (page) => {
    fetchUsers(page);
  };

  useEffect(() => {
    fetchUsers(1);
  }, []);

  return (
    <DefaultDashboardLayout>
      <DataTable
        title="Volunteers"
        columns={columns}
        data={data}
        progressPending={loading}
        pagination
        paginationServer
        paginationTotalRows={totalRows}
        onChangePage={handlePageChange}
      />
    </DefaultDashboardLayout>
  );
}

export default Page;
