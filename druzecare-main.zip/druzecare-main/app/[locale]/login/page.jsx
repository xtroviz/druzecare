import React from 'react';
import getTranslation from '@/lib/i18n/getTranslation';
import Login from '@/components/common/Login';
import Signup from '@/components/common/Signup';
import Banner from '@/components/common/Banner';
import bannerImage from '@/public/main-banner.png';
import DefaultLayout from '@/components/Layouts/DefaultLayout';

async function Page({ params }) {
  const translation = await getTranslation(params.locale);

  return (
    <DefaultLayout params={params}>
      <Banner
        image={bannerImage}
        sub_heading={translation('views.main.login')}
      />
      <Login />
    </DefaultLayout>
  );
}

export default Page;
