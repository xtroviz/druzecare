import Dashboard from '@/components/Dashboard/Dashboard';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';

export const metadata = {
  title: 'Admin Dashboard',
  description: 'This is Admin Dashboard.',
};

export default function Home() {
  return (
    <>
      <DefaultDashboardLayout>
        <Dashboard />
      </DefaultDashboardLayout>
    </>
  );
}
