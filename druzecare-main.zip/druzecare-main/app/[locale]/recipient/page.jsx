import React from 'react';
import RecepientForm from '@/components/common/RecepientForm';
import Banner from '@/components/common/Banner';
import bannerImage from '@/public/main-banner.png';
import getTranslation from '@/lib/i18n/getTranslation';
import DefaultLayout from '@/components/Layouts/DefaultLayout';

const Page = async ({ params }) => {
  const translation = await getTranslation(params.locale);

  return (
    <DefaultLayout params={params}>
      <Banner
        image={bannerImage}
        heading={translation('views.main.need-heartful-help')}
        sub_heading={translation('views.main.become-a-recipient')}
      />
      <div className="container mx-auto my-10 p-6 text-gray-900 lg:p-12">
        <div className="flex flex-col lg:flex-row">
          <div className="pb-4 lg:w-1/2 lg:pr-12">
            <h1 className="__className_9c7bc7 textRed text-left text-3xl">
              {translation('views.main.need-heartful-help')}
            </h1>
            <div className="__className_c8bfae mt-2">
              <h2 className="mb-4 text-2xl font-bold">
                {translation('views.main.become-a-recipient')}
              </h2>
            </div>
            <p>
             {translation('views.main.need-heartful-help-desc')}
            </p>
          </div>
          <div className="lg:w-1/2 lg:pl-12">
            {Array.from({ length: 4 }, (_, i) => (
              <div className="mb-6" key={i}>
                <div className="mb-2 flex items-center">
                  <span className="bgBrandRed mr-4 flex h-8 w-8 items-center justify-center rounded-full px-2 text-white">
                    0{i + 1}
                  </span>
                  <div className="__className_c8bfae">
                    <h3 className="font-bold">
                      {translation(
                        'views.main.recipient-need-heartful-help-title-' +
                          (i + 1)
                      )}
                    </h3>
                  </div>
                </div>
                <p>
                  {translation(
                    'views.main.recipient-need-heartful-help-desc-' + (i + 1)
                  )}
                </p>
                <hr className="mb-3 mt-6" />
              </div>
            ))}
          </div>
        </div>
        <div className="mt-2 lg:px-28">
          <div className="__className_c8bfae">
            <h1 className="text-color mb-4 text-2xl">
              {translation('views.main.complete-the-form')}
            </h1>
          </div>
          <h2 className="textRed mb-4 text-xl">
            {translation('views.main.fill-recipient-form')}
          </h2>
          <RecepientForm />
        </div>
      </div>
    </DefaultLayout>
  );
};

export default Page;
