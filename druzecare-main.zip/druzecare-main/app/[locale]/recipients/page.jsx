'use client';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import axios from 'axios';
import { FaRegEdit } from 'react-icons/fa';
import Link from 'next/link';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import Swal from 'sweetalert2';
import Cookies from 'js-cookie';

function Page() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);
  const currentUser = JSON.parse(Cookies.get('currentUser')).user;
  var toast = Swal.mixin({
    toast: true,
    icon: 'success',
    title: 'General Title',
    animation: true,
    position: 'top-right',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    },
  });

  const fetchUsers = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/users?role=Recipient&page=${page}&limit=${perPage}&sort_by=created_at&order=desc`;

    axios
      .get(url)
      .then((response) => {
        setData(response.data.user);
        setTotalRows(response.data.total);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handleUpdateStatus = (is_active) => {
    setLoading(true);
    const url = `http://localhost:5000/user/profile/update`;

    const data = {
      country_id: currentUser.country_id,
      is_active: parseInt(is_active),
    };

    axios
      .patch(url, data, {
        withCredentials: true,
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        toast.fire({
          animation: true,
          title: response.data.message,
        });
        fetchUsers();
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        toast.fire({
          icon: 'error',
          animation: true,
          title: err?.response?.data?.message,
        });
      });
  };
  const columns = [
    {
      name: 'Username',
      selector: (row) => row.username,
      sortable: true,
    },
    {
      name: 'Email',
      selector: (row) => row.email,
      sortable: true,
    },
    {
      name: 'City',
      selector: (row) => row.city,
      sortable: true,
    },
    {
      name: 'Phone',
      selector: (row) => row.phone,
      sortable: true,
    },
    {
      name: 'Status',
      selector: (row) => (
        <select
          className={`block w-full appearance-none  px-4 py-3 pr-8 text-white focus:outline-none ${
            row.is_active ? 'bg-green-400' : 'bg-red-400'
          }`}
          onChange={(e) => handleUpdateStatus(e.target.value)}
          defaultValue={row.is_active ? '1' : '0'}
        >
          <option value="0">In Active</option>
          <option value="1">Active</option>
        </select>
      ),
      sortable: true,
    },
    {
      name: 'Actions',
      button: true,
      cell: (data) => (
        <div className="flex">
          <Link
            href={`/recipients/edit`}
            onClick={(e) =>
              localStorage.setItem('edit_recipient', JSON.stringify(data))
            }
          >
            <FaRegEdit className="text-success mx-1 h-[20px] w-[20px] cursor-pointer" />
          </Link>
        </div>
      ),
    },
  ];

  const handlePageChange = (page) => {
    fetchUsers(page);
  };

  const handlePerRowsChange = (newPerPage, page) => {
    setLoading(true);
    const url = `http://localhost:5000/users?role=Recipient&is_active=1&is_blocked=0&page=${page}&limit=${perPage}&sort_by=created_at&order=desc`;

    axios
      .get(url)
      .then((response) => {
        setData(response.data.user);
        setPerPage(newPerPage);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handleSort = (column, sortDirection) => {
    setLoading(true);
    const url = `http://localhost:5000/users?role=Recipient&is_active=1&is_blocked=0&limit=${perPage}&sort_by=${column.name}&order=${sortDirection}`;

    axios
      .get(url)
      .then((response) => {
        setData(response.data.user);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  useEffect(() => {
    fetchUsers(1);
  }, []);

  return (
    <DefaultDashboardLayout>
      <DataTable
        title="Recipients"
        columns={columns}
        data={data}
        progressPending={loading}
        pagination
        paginationServer
        paginationTotalRows={totalRows}
        onChangeRowsPerPage={handlePerRowsChange}
        onChangePage={handlePageChange}
        onSort={handleSort}
      />
    </DefaultDashboardLayout>
  );
}

export default Page;
