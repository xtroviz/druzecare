import React from 'react';
import getTranslation from '@/lib/i18n/getTranslation';
import Signup from '@/components/common/Signup';
import Banner from '@/components/common/Banner';
import bannerImage from '@/public/main-banner.png';
import DefaultLayout from '@/components/Layouts/DefaultLayout';

async function Page({ params }) {
  const translation = await getTranslation(params.locale);

  return (
    <DefaultLayout params={params}>
      <Banner
        image={bannerImage}
        sub_heading={translation('views.main.signUp')}
      />
      <Signup />
    </DefaultLayout>
  );
}

export default Page;
