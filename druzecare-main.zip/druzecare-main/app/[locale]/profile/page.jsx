import React from 'react';
import DefaultDashboardLayout from '@/components/Layouts/DefaultDashboardLayout';
import Profile from '@/components/profile/Profile';

function page() {
  return (
    <DefaultDashboardLayout>
      <Profile />
    </DefaultDashboardLayout>
  );
}

export default page;
