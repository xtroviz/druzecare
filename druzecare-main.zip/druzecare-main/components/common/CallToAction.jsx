import React from 'react';
import {
  FaFacebook,
  FaTwitter,
  FaInstagram,
  FaPinterest,
  FaHandHoldingHeart,
} from 'react-icons/fa';

const CallToAction = ({ translation }) => (
  <div className="Home_aboutG1__A8A15 mb-7 mt-4 flex flex-col items-center justify-center p-5 md:p-8 text-white shadow-lg">
    <div className="bgBlack rounded-full px-4 py-3">
      <FaHandHoldingHeart className="mb-2 text-white" size={32} />
    </div>
    <div className="__className_c8bfae">
      <h2 className="text-color my-3 text-lg font-bold">
        {translation('views.main.become-a-volunteer')}
      </h2>
    </div>
    <p className="text-color mb-4 font-semibold">
      &quot;
      {translation('views.main.help-who-help-others')}&quot;
    </p>
    <button className="bgBlack rounded-full px-6 py-3 text-white">
      {translation('views.main.join-us-today')}
    </button>
  </div>
);

export default CallToAction;
