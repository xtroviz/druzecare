'use client';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { redirect } from 'next/navigation';
import { setUser } from '@/reducers/authReducer';
import { useAppDispatch } from '@/state/hooks';
import Cookies from 'js-cookie';
import Swal from 'sweetalert2';

function DonorForm() {
  const [states, setStates] = useState([]);
  const [userRedirect, setUserRedirect] = useState(false);
  const dispatch = useAppDispatch();

  const fields = [
    'User Name*',
    'Password*',
    'First Name*',
    'Last Name*',
    'Phone Number*',
    'Email Address*',
    'City*',
  ];

  const handleSignup = (e) => {
    e.preventDefault();

    axios
      .post(
        'http://localhost:5000/register',
        {
          username: e.target.username.value,
          firstname: e.target.firstname.value,
          lastname: e.target.lastname.value,
          email: e.target.emailaddress.value,
          phone: e.target.phonenumber.value,
          country_id:
            e.target.country.options[e.target.country.selectedIndex].id,
          city: e.target.city.value,
          role: 'Donor',
          password: e.target.password.value,
          is_visible: 0,
          is_active: 0,
        },
        {
          withCredentials: true,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
          },
        }
      )
      .then((res) => {
        dispatch(setUser(res.data));
        Cookies.set('currentUser', JSON.stringify(res.data), { expires: 30 });
        setUserRedirect(true);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        Swal.mixin({
          toast: true,
          icon: 'success',
          title: 'General Title',
          animation: true,
          position: 'top-right',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
          },
        }).fire({
          icon: 'error',
          animation: true,
          title: err.message,
        });
      });
  };

  useEffect(() => {
    if (userRedirect) redirect('/dashboard');
  }, [userRedirect]);

  useEffect(() => {
    axios
      .get('http://localhost:5000/countries')
      .then((res) => {
        setStates(res.data.data);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  }, []);

  return (
    <form className="text-black" onSubmit={handleSignup}>
      {fields.map((label, index) => {
        const currLabel = label.replace(' ', '').replace('*', '').toLowerCase();
        return (
          <div
            className={`mb-4 ${
              index % 2 === 0
                ? 'md:inline-block md:w-1/2 md:px-2'
                : 'md:inline-block md:w-1/2 md:px-2'
            }`}
            key={label}
          >
            <input
              required
              name={currLabel}
              type={
                currLabel === 'password'
                  ? 'password'
                  : currLabel === 'phonenumber'
                    ? 'number'
                    : currLabel === 'emailaddress'
                      ? 'email'
                      : 'text'
              }
              id={label}
              placeholder={label}
              className="relative block w-full appearance-none rounded-none rounded-t-md bg-gray-100 px-5 py-5 text-xl text-gray-900 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500"
            />
          </div>
        );
      })}
      <div className={`mb-4 md:inline-block md:w-1/2 md:px-2`}>
        <div className="mb-3">
          <label htmlFor="country">Country</label>
          <div className="relative">
            <select
              id="country"
              name="country"
              required
              className="relative block w-full appearance-none rounded-none rounded-t-md bg-gray-100 px-5 py-5 text-xl text-gray-900 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500"
              style={{ color: 'gray' }}
            >
              {states.map((el) => (
                <option key={el._id} id={el._id}>
                  {el.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      <div className="">
        <button className="bgBlack flex rounded-full px-20 py-4 font-semibold text-white">
          {' '}
          SUBMIT
        </button>
      </div>
    </form>
  );
}

export default DonorForm;
