'use client';
import React, { useRef } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import Cookies from 'js-cookie';

const HomeBanner = ({ text_placeholder, text_submit }) => {
  const emailRef = useRef('');
  var toast = Swal.mixin({
    toast: true,
    icon: 'success',
    title: 'General Title',
    animation: true,
    position: 'top-right',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    },
  });

  const handlesSubmit = (e) => {
    e.preventDefault();
    if (e.target.email.value != '') {
      axios
        .post(
          'http://localhost:5000/newsletter/create',
          {
            email: e.target.email.value,
          },
          {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        )
        .then((res) => {
          if (res.data.status && res.data.status == 201) {
            toast.fire({
              animation: true,
              title: res.data.message,
            });
          } else {
            toast.fire({
              icon: 'error',
              animation: true,
              title: res.data.message,
            });
          }
        })
        .catch((err) => {
          Cookies.set('removeCookies', 'true');
          toast.fire({
            icon: 'error',
            animation: true,
            title: res.data.message,
          });
        });
    } else {
      toast.fire({
        icon: 'error',
        animation: true,
        title: 'Please enter valid email to subscribe!',
      });
    }
  };

  return (
    <form onSubmit={handlesSubmit} className="flex justify-between">
      <input
        type="email"
        name="email"
        id="email"
        placeholder={text_placeholder}
        className="flex-grow rounded-full px-5 py-3"
        ref={emailRef}
      />
      <button
        type="submit"
        className="ml-2 w-24 rounded-full bg-[#2e4049] p-2 text-white"
      >
        {text_submit}
      </button>
    </form>
  );
};

export default HomeBanner;
