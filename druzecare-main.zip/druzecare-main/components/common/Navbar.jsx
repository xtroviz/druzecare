'use client';
import React, { useState } from 'react';
import styles from '../styles/Navbar.module.css';
import Logo from '../../public/logo.png';
import Link from 'next/link';
import Image from 'next/image';
import LocaleSelector from './LocaleSelector';
import { FaBars, FaTimes } from 'react-icons/fa';

const Navbar = ({ translations }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigation = [
    { name: translations.home, href: '/', current: true, color: 'textGreen' },
    {
      name: translations.about,
      href: '/about',
      current: false,
      color: 'textRed',
    },
    {
      name: translations.donor,
      href: '/donor',
      current: false,
      color: 'textYellow',
    },
    {
      name: translations.recipient,
      href: '/recipient',
      current: false,
      color: 'textPurple',
    },
    {
      name: translations.explore,
      href: '/explore',
      current: false,
      color: 'textBlue',
    },
    {
      name: translations.contact,
      href: '/contact',
      current: false,
      color: 'textLightBlue',
    },
  ];

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className={`bgSkyBlue relative h-32 w-full`}>
      <div className="container mx-auto flex h-full items-center justify-between">
        <div>
          <Link href="/">
            <Image src={Logo} className="cursor-pointer" alt="Logo" />
          </Link>
        </div>
        <div className="sm:hidden">
          {!isMenuOpen ? (
            <FaBars className="text-2xl text-white" onClick={toggleMenu} />
          ) : (
            <FaTimes className="text-2xl text-white" onClick={toggleMenu} />
          )}
        </div>
        {/* Menu for Mobile */}
        <div
          className={`${
            isMenuOpen ? 'block' : 'hidden'
          } fixed left-0 top-0 z-50 h-full w-60 bg-white sm:hidden`}
        >
          <div className="flex items-center justify-between p-4">
            <div></div>
            <FaTimes className="text-2xl text-gray-600" onClick={toggleMenu} />
          </div>
          <ul className="m-2 mt-8 flex flex-col items-start">
            {navigation.map((item, index) => (
              <li
                key={index}
                className={`text-l mb-1 w-55 rounded-full border-2 bg-gray-100 p-2 px-5 font-semibold first-letter:uppercase hover:text-black`}
              >
                <Link href={item.href} className={`block w-full ${item.color}`}>
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        {/* End of Mobile Menu */}
        <div className="hidden items-center justify-center sm:flex sm:flex-grow">
          <ul className="flex">
            {navigation.map((item, index) => (
              <li
                key={index}
                className={`text-l w-max border-r-2 px-2 font-semibold first-letter:uppercase hover:text-black lg:px-5`}
              >
                <Link href={item.href} className={item.color}>
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="relative mx-5">
          <LocaleSelector message={'locale selector'} />
        </div>
        {/* "Become a member" Button */}
        <div className="ml-auto sm:block">
          <Link
            href="/login"
            className={`bgBrandRed max-w-xs truncate rounded-full px-3 py-2 font-normal uppercase text-white`}
          >
            {translations.member}
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
