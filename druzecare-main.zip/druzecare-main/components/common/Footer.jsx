import React from 'react';
import Image from 'next/image';
import footerImg from '@/public/logo.png';

import {
  FaFacebook,
  FaTwitter,
  FaInstagram,
  FaPinterest,
} from 'react-icons/fa';

const Footer = ({ translation }) => {
  return (
    <footer className="bg-[#2e4049] px-5 md:px-10">
      <div className="container mx-auto grid grid-cols-1 gap-5 py-10 md:grid-cols-8 md:p-20">
        <div className="col-span-3 flex flex-col">
          <div className="mb-5 md:mb-0">
            <Image src={footerImg} className="inline-block h-full p-5" />
          </div>
          <p className="text-white">{translation('views.main.footer-desc')}</p>
          <div className="my-5 flex">
            <FaFacebook className="mx-3 text-white" />
            <FaTwitter className="mx-3 text-white" />
            <FaInstagram className="mx-3 text-white" />
            <FaPinterest className="mx-3 text-white" />
          </div>
        </div>
        <div className="col-span-5">
          <div className="grid grid-cols-1 gap-5 rounded-lg bg-white bg-opacity-10 p-5 md:grid-cols-3">
            <div>
              <h2 className="__className_b70e47 mb-3 text-sm font-semibold uppercase text-white ">
                {translation('views.main.get-involved')}
              </h2>
              <ul className="font-medium text-white">
                <li className="mb-1">
                  <a href="/" className="hover:text-red hover:text-amber-600">
                    {translation('views.main.home')}
                  </a>
                </li>
                <li className="mb-1">
                  <a
                    href="/about"
                    className="hover:text-red hover:text-amber-600"
                  >
                    {translation('views.main.about-us')}
                  </a>
                </li>
                <li className="mb-1">
                  <a
                    href="/explore"
                    className="hover:text-red hover:text-amber-600"
                  >
                    {translation('views.main.explore')}
                  </a>
                </li>
                <li className="mb-1">
                  <a
                    href="/contact"
                    className="hover:text-red hover:text-amber-600"
                  >
                    {translation('views.main.contact-us')}
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h2 className="__className_b70e47 mb-3 text-sm font-semibold uppercase text-white ">
                {translation('views.main.utility')}
              </h2>
              <ul className="font-medium text-white">
                <li className="mb-1">
                  <a
                    href="/login"
                    className="hover:text-red hover:text-amber-600"
                  >
                    {translation('views.main.log_in')}
                  </a>
                </li>
                <li className="mb-1">
                  <a
                    href="/login"
                    className="hover:text-red hover:text-amber-600"
                  >
                    {translation('views.main.signUp')}
                  </a>
                </li>
                <li className="mb-1">
                  <a
                    href="/recipient"
                    className="hover:text-red hover:text-amber-600"
                  >
                    {translation('views.main.recipient')}
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h2 className="__className_b70e47 mb-3 text-sm font-semibold uppercase text-white ">
                {translation('views.main.contact')}
              </h2>
              <ul className="font-medium text-white">
                <li className="mb-1">
                  <a href="#" className="hover:text-red hover:text-amber-600">
                    {translation('views.main.address-1')}
                  </a>
                </li>
                <li className="mb-1">
                  <a href="#" className="hover:text-red hover:text-amber-600">
                    {translation('views.main.address-2')}
                  </a>
                </li>
                <li className="mb-1">&nbsp;</li>
                <li className="mb-1">
                  <a href="#" className="hover:text-red hover:text-amber-600">
                    {translation('views.main.email')}
                  </a>
                </li>
                <li className="mb-1">
                  <a href="#" className="hover:text-red hover:text-amber-600">
                    {translation('views.main.contact-no')}
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <hr className="my-5 border-t border-gray-600" />
          <div className="p-3 text-center text-white">
            {translation('views.main.copyright')}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
