'use client';
import React, { useState, useRef, useEffect } from 'react';
import {
  FaChevronDown,
  FaFilter,
  FaThLarge,
  FaEllipsisV,
} from 'react-icons/fa';
import Card from '@/components/common/Card';
import axios from 'axios';
import Cookies from 'js-cookie';

function Page({ translations, params }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchUsers = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/users?role=Recipient&is_active=1&is_blocked=0&page=1&limit=12&sort_by=created_at&order=desc`;

    axios
      .get(url)
      .then((response) => {
        setData(response.data.user);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  useEffect(() => {
    fetchUsers(1);
  }, []);

  return (
    <div className="container mx-auto mb-20 mt-20 p-4 sm:px-8 md:px-12 lg:px-20">
      {/* <div className="flex flex-col items-center justify-between bg-orange-200 p-6 font-semibold sm:flex-row  sm:p-4">
        <div className="flex items-center gap-5">
          <div className="flex items-center space-x-2">
            <FaFilter />
            <div>Filter</div>
          </div>
          <FaThLarge />
          <FaEllipsisV />
          <div className="h-6 border-l-4 border-black"></div>
          <div>Showing Person 1-16 of 32 results</div>
          <div className="flex items-center space-x-2"></div>
        </div>

        <div className="flex">
          <div className="relative me-4 flex items-center">
            <div className="me-4">Show</div>
            <button className="rounded-full bg-red-500 px-4 py-3 text-white">
              16
            </button>
          </div>
          <div className="relative flex items-center">
            <div className="me-4">Sort by</div>
            <div className="relative">
              <button className="flex items-center rounded-full bg-red-500 px-6 py-3 text-white">
                <FaChevronDown className="ml-2" />
              </button>
              {isOpen && (
                <div className="divide-gray-100 border-gray-200 absolute right-0 mt-2 w-48 divide-y rounded-md border bg-white shadow-lg">
                  <div className="py-1">
                    {donors.map((donor) => (
                      <a
                        key={donor}
                        href="#"
                        onClick={() => handleSelect(donor)}
                        className="text-gray-700 hover:bg-gray-100 block px-4 py-2 text-sm"
                      >
                        {donor}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div> */}
      {loading ? (
        <h1 className="p-10 text-center text-5xl">{translations.loading}</h1>
      ) : (
        <div className="container mt-10 grid grid-cols-1 gap-4 sm:mt-20 sm:grid-cols-2 sm:px-8 md:grid-cols-3 md:px-12 lg:grid-cols-4 lg:px-20">
          {data.map((recipient, i) => (
            <Card
              params={params}
              translations={translations}
              key={i}
              id={recipient._id}
              story={recipient.story}
              story_ar={recipient.story_ar}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default Page;
