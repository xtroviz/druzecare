import { useState, useEffect, useRef } from 'react';
import { FaUserPlus } from 'react-icons/fa';
import { Transition } from '@headlessui/react';
import { redirect } from 'next/navigation';
import Cookies from 'js-cookie';
import axios from 'axios';
import Swal from 'sweetalert2';
import Image from 'next/image';
import recipientAvatar from '@/public/recepientAvtar.png';

const Card = ({ id, story, params, story_ar, translations }) => {
  const [userRedirect, setUserRedirect] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const modalRef = useRef(null);
  const contactModalRef = useRef(null);
  const [amount, setAmount] = useState('');
  var toast = Swal.mixin({
    toast: true,
    icon: 'success',
    title: 'General Title',
    animation: true,
    position: 'top-right',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    },
  });
  const handleAmountChange = (event) => {
    const sanitizedValue = event.target.value.replace(/\D/g, '');
    setAmount(sanitizedValue);
  };
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setIsOpen(false);
      }
      if (
        contactModalRef.current &&
        !contactModalRef.current.contains(event.target)
      ) {
        setShowContactModal(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();

    const currUser = Cookies.get('currentUser');
    setShowContactModal(false);
    if (currUser) {
      axios
        .post(
          'http://localhost:5000/donor-request/create',
          {
            recipient_id: id,
            amount: e.target.amount.value,
            type: e.target.type.value,
          },
          {
            withCredentials: true,
            headers: {
              'Content-Type': 'application/json',
            },
          }
        )
        .then((res) => {
          toast.fire({
            animation: true,
            title: 'Request Sent Successfully.',
          });
        })
        .catch((err) => {
          Cookies.set('removeCookies', 'true');
          toast.fire({
            icon: 'error',
            animation: true,
            title: err.message,
          });
        });
    } else {
      setUserRedirect(true);
    }
  };

  useEffect(() => {
    if (userRedirect) redirect('/login');
  }, [userRedirect]);

  return (
    <div className="mb-8 flex flex-col items-center justify-center">
      <Image
        className="mb-2 h-[18rem] w-100"
        src={recipientAvatar}
        alt={name}
      />
      <div ref={modalRef}>
        <button
          onClick={() => setIsOpen(true)}
          className="align-center mb-3 flex rounded-full bg-red-500 px-4 py-2 font-semibold text-white"
        >
          <span className="text-xs">{translations.showStory}</span>
        </button>
      </div>
      <button
        onClick={() => setShowContactModal(true)}
        className="bgBlack align-center flex rounded-full px-7 py-4 font-semibold text-white"
      >
        {' '}
        <FaUserPlus className="mr-2 text-sm" />
        <span className="w-max text-xs">{translations.connectNow}</span>
      </button>

      <Transition
        show={isOpen}
        enterFrom="opacity-0"
        enterTo="opacity-100"
        leave="transition-opacity duration-300"
        leaveFrom="opacity-100"
        leaveTo="opacity-0"
      >
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div
            className="mx-4 my-8 w-full max-w-md rounded-lg bg-white p-8"
            onClick={() => setIsOpen(false)}
          >
            <h1 className="mb-4 text-lg font-bold">{translations.story}</h1>
            <p className="text-gray-700">
              {params.locale === 'en' ? story : story_ar}
            </p>
            <button
              className="mt-4 rounded-lg bg-red-500 px-4 py-2 text-white"
              onClick={() => setIsOpen(false)}
            >
              {translations.close}
            </button>
          </div>
        </div>
      </Transition>

      <Transition
        show={showContactModal}
        enter="transition-opacity duration-300"
        enterFrom="opacity-0"
        enterTo="opacity-100"
        leave="transition-opacity duration-300"
        leaveFrom="opacity-100"
        leaveTo="opacity-0"
      >
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div
            ref={contactModalRef}
            className="mx-4 my-8 w-full max-w-md rounded-lg bg-white p-8"
          >
            <h1 className="mb-4 text-lg font-bold">
              {translations.connectNow}
            </h1>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label
                  className="mb-2 block text-sm font-bold text-gray-700"
                  htmlFor="amount"
                >
                  {translations.amount}
                </label>
                <input
                  className="focus:shadow-outline w-full appearance-none rounded border px-3 py-2 leading-tight text-gray-700 shadow focus:outline-none"
                  id="amount"
                  type="number"
                  name="amount"
                  value={amount}
                  onChange={handleAmountChange}
                  placeholder="Enter Amount"
                />
              </div>
              <div className="mb-4">
                <label
                  className="mb-2 block text-sm font-bold text-gray-700"
                  htmlFor="type"
                >
                  {translations.type}
                </label>
                <select
                  name="type"
                  id="type"
                  className="focus:shadow-outline w-full appearance-none rounded border px-3 py-2 leading-tight text-gray-700 shadow focus:outline-none"
                >
                  <option value="monthly">Monthly</option>
                  <option value="lumpsum">Lumpsum</option>
                </select>
              </div>
              <button
                type="Connect"
                className="bgBlack me-3 mt-4 rounded-lg px-4 py-2 text-white"
              >
                {translations.submit}
              </button>
              <button
                className="mt-4 rounded-lg bg-red-500 px-4 py-2 text-white"
                onClick={() => setShowContactModal(false)}
              >
                {translations.close}
              </button>
            </form>
          </div>
        </div>
      </Transition>
    </div>
  );
};

export default Card;
