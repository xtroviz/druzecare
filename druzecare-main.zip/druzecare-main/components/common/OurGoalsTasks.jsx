import React from 'react';
import { FaCheckCircle } from 'react-icons/fa';

function OurGoalsTasks({ name }) {
  return (
    <div className="relative grid grid-cols-12 rounded-full bg-[#f2f2f2] px-3 py-2 ">
      <FaCheckCircle className="self-center justify-self-center text-amber-600" />
      <span className={`col-span-10 pl-2 text-[#7d7d7d]`}>{name}</span>
    </div>
  );
}

export default OurGoalsTasks;
