'use client';
import React, { useState, useEffect } from 'react';
import { FaChevronDown } from 'react-icons/fa';
import axios from 'axios';
import { redirect } from 'next/navigation';
import { setUser } from '@/reducers/authReducer';
import { useAppDispatch } from '@/state/hooks';
import Cookies from 'js-cookie';
import Swal from 'sweetalert2';

function Signup() {
  const [userType, setUserType] = useState('donor');
  const [states, setStates] = useState([]);
  const [userRedirect, setUserRedirect] = useState(false);
  const dispatch = useAppDispatch();

  const handleSignup = (e) => {
    e.preventDefault();

    const data = {
      username: e.target.username.value,
      firstname: e.target.firstname.value,
      lastname: e.target.lastname.value,
      email: e.target.email.value,
      phone: e.target.phone.value,
      country_id: e.target.country.options[e.target.country.selectedIndex].id,
      city: e.target.city.value,
      role: e.target.userType.value,
      password: e.target.password.value,
      confirm_password: e.target.confirmPassword.value,
      is_visible: 0,
      is_active: 0,
    };

    if (userType === 'Recipient') data.story = e.target.story.value;

    axios
      .post('http://localhost:5000/register', data, {
        withCredentials: true,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json',
        },
      })
      .then((res) => {
        dispatch(setUser(res.data));
        Cookies.set('currentUser', JSON.stringify(res.data), { expires: 30 });
        setUserRedirect(true);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        Swal.mixin({
          toast: true,
          icon: 'success',
          title: 'General Title',
          animation: true,
          position: 'top-right',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
          },
        }).fire({
          icon: 'error',
          animation: true,
          title: err.message,
        });
      });
  };

  useEffect(() => {
    if (userRedirect) redirect('/dashboard');
  }, [userRedirect]);

  useEffect(() => {
    axios
      .get('http://localhost:5000/countries')
      .then((res) => {
        setStates(res.data.data);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  }, []);

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
      <div className="login-shadow w-full space-y-8 rounded-2xl p-8 sm:w-2/3 sm:p-12 md:w-2/3 lg:w-2/5 lg:p-14 xl:w-1/3">
        <div className="__className_c8bfae text-color">
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Sign Up
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSignup}>
          <div className="-space-y-px">
            <div className="mb-3">
              <label htmlFor="user-type" className="sr-only">
                User Type
              </label>
              <div className="relative">
                <select
                  id="user-type"
                  name="userType"
                  required
                  className="relative block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                  onChange={(e) => setUserType(e.target.value)}
                  value={userType}
                >
                  <option value="Donor" className="px-4 py-3">
                    Sign Up As Donor
                  </option>
                  <option value="Recipient">Sign Up As Recipient</option>
                </select>
                <FaChevronDown className="absolute right-3 top-1/2 z-20 -translate-y-1/2 transform text-gray-400" />
              </div>
            </div>
          </div>
          <div>
            <label htmlFor="username" className="mb-2">
              User Name
            </label>
            <input
              name="username"
              type="text"
              id="username"
              placeholder="username"
              className="relative mb-3 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="firstname" className="mb-2">
              First Name
            </label>
            <input
              name="firstname"
              type="text"
              id="firstname"
              placeholder="Firstname"
              className="relative mb-3 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="lastname" className="mb-2">
              Last Name
            </label>
            <input
              name="lastname"
              type="text"
              id="lastname"
              placeholder="Lastname"
              className="relative mb-3 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="email-address" className="mb-2">
              Email
            </label>
            <input
              name="email"
              type="email"
              id="email-address"
              placeholder="Email"
              size="50"
              className="relative mb-3 mb-4 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="phone" className="mb-2">
              Phone
            </label>
            <input
              name="phone"
              type="number"
              id="phone"
              placeholder="Phone"
              size="50"
              className="relative mb-3 mb-4 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div className="-space-y-px">
            <div className="mb-3">
              <label htmlFor="country">Country</label>
              <div className="relative">
                <select
                  id="country"
                  name="country"
                  required
                  className="relative block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                >
                  {states.map((el) => (
                    <option key={el._id} id={el._id}>
                      {el.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          <div>
            <label htmlFor="city" className="mb-2">
              City
            </label>
            <input
              name="city"
              type="text"
              id="city"
              placeholder="City"
              size="50"
              className="relative mb-3 mb-4 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="password" className="mb-2">
              Password
            </label>
            <input
              name="password"
              type="password"
              id="password"
              placeholder="Password"
              className="relative mb-3 mb-4 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="confirm-password" className="mb-2">
              Confirm Password
            </label>
            <input
              name="confirmPassword"
              type="password"
              id="confirm-password"
              placeholder="Confirm Password"
              className="relative mb-3 mb-4 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <div className={userType === 'Recipient' ? 'block' : 'hidden'}>
            <label htmlFor="message" className="mb-2">
              Story
            </label>
            <textarea
              name="story"
              rows="5"
              id="message"
              className="relative mb-3 mb-4 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              placeholder="Write Your Story..."
              required={userType === 'Recipient' ? true : false}
            ></textarea>
          </div>

          <div className="mt-6 flex justify-center">
            <button
              type="submit"
              className="bgBlack flex rounded-full px-20 py-4 font-semibold text-white"
            >
              SIGN UP
            </button>
          </div>
        </form>
        <div className="text-center">
          <p className="text-sm text-gray-600">
            Already have an account?{' '}
            <a
              href="/login"
              className="text-color font-bold text-indigo-600 hover:text-indigo-500"
            >
              {' '}
              Login
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Signup;
