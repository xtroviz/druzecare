'use client';
import React from 'react';
import Image from 'next/image';
import bannerImage from '@/public/project1.png';

import { useEffect, useState } from 'react';

function Banner({ image, heading, sub_heading, sub_heading2 }) {
  const [bannerHeight, setBannerHeight] = useState(0);

  useEffect(() => {
    const handleResize = () => {
      const navHeight = document.querySelector('nav').offsetHeight;
      const windowHeight = window.innerHeight;
      setBannerHeight(windowHeight - navHeight);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="relative" style={{ height: bannerHeight }}>
      <Image src={image} className="h-full w-full object-cover" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 transform text-center">
        <h4
          className={`sue-ellen  mb-2 text-4xl text-white md:text-5xl lg:text-6xl`}
        >
          {heading}
        </h4>
        <h3
          className={`shippori-mincho-bold mt-5 text-5xl text-white md:text-6xl lg:text-7xl`}
        >
          {sub_heading} <br /> {sub_heading2}
        </h3>
      </div>
    </div>
  );
}

export default Banner;
