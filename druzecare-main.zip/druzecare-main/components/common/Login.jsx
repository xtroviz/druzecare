'use client';
import React, { useState, useEffect } from 'react';
import { FaEnvelope, FaLock } from 'react-icons/fa';
import axios from 'axios';
import { redirect } from 'next/navigation';
import { setUser } from '@/reducers/authReducer';
import { useAppDispatch } from '@/state/hooks';
import Cookies from 'js-cookie';
import Swal from 'sweetalert2';

function Login() {
  const [userRedirect, setUserRedirect] = useState(false);
  const dispatch = useAppDispatch();

  const handleLogin = (e) => {
    e.preventDefault();

    axios
      .post(
        'http://localhost:5000/login',
        {
          username: e.target.email.value,
          password: e.target.password.value,
        },
        {
          withCredentials: true,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
          },
        }
      )
      .then((res) => {
        dispatch(setUser(res.data));
        Cookies.set('currentUser', JSON.stringify(res.data), { expires: 30 });
        setUserRedirect(true);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        Swal.mixin({
          toast: true,
          icon: 'success',
          title: 'General Title',
          animation: true,
          position: 'top-right',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
          },
        }).fire({
          icon: 'error',
          animation: true,
          title: 'Please Check Your Credentials and Try Again.',
        });
      });
  };

  useEffect(() => {
    if (userRedirect) redirect('/dashboard');
  }, [userRedirect]);

  useEffect(() => {
    if (Cookies.get('currentUser')) setUserRedirect(true);
  }, []);

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
      <div className="login-shadow w-full space-y-8 rounded-2xl p-8 sm:w-2/3 sm:p-12 md:w-2/3 lg:w-2/5 lg:p-14 xl:w-1/3">
        <div className="__className_c8bfae text-color">
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Log In
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          <input type="hidden" name="remember" value="true" />
          <div className="-space-y-px rounded-md shadow-sm">
            <div>
              <label htmlFor="email-address" className="sr-only">
                Email address
              </label>
              <div className="relative">
                <FaEnvelope className="absolute left-3 top-1/2 z-20 -translate-y-1/2 transform text-gray-400" />
                <input
                  id="email-address"
                  name="email"
                  type="text"
                  size="50"
                  autoComplete="email"
                  required
                  className="relative mb-4 block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-5 py-4 pl-10 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                  placeholder="johndoe@gmail.com"
                />
              </div>
            </div>
            <div>
              <label htmlFor="password" className="sr-only">
                Password
              </label>
              <div className="relative">
                <FaLock className="absolute left-3 top-1/2 z-20 -translate-y-1/2 transform text-gray-400" />
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  className="relative block w-full appearance-none rounded-none rounded-b-md border border-gray-300 px-5 py-4 pl-10 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                  placeholder="**********"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <button
              type="submit"
              className="bgBlack flex rounded-full px-20 py-4 font-semibold text-white"
            >
              LOGIN
            </button>
          </div>
        </form>
        <div className="text-center">
          <p className="text-sm text-gray-600">
            Don&apos;t have an account?{' '}
            <a
              href="signup"
              className="text-color font-bold text-indigo-600 hover:text-indigo-500"
            >
              Sign Up
            </a>
          </p>
          <p className="mt-3 text-sm text-gray-600">
            <a
              href="reset"
              className="text-color font-bold text-indigo-600 hover:text-indigo-500"
            >
              Forgot Password?
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;
