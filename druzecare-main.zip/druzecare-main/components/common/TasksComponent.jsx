import React from 'react';

function TasksComponent({ name, icon }) {
  return <div></div>;
}

export default TasksComponent;
