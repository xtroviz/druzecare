import React from 'react';
import Navbar from './Navbar';

const Header = ({ translation }) => {
  const translations = {
    home: translation('views.main.home'),
    about: translation('views.main.about-us'),
    donor: translation('views.main.donor'),
    recipient: translation('views.main.recipient'),
    explore: translation('views.main.explore'),
    contact: translation('views.main.contact-us'),
    member: translation('views.main.become-a-member'),
  };
  return <Navbar translations={translations} />;
};

export default Header;
