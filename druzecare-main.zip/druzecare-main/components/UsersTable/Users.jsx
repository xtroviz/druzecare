'use client';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import axios from 'axios';
import { FaRegEdit } from 'react-icons/fa';
import Link from 'next/link';
import Cookies from 'js-cookie';

function Page({ redirectLink, filterLink, Heading, record }) {
  const [states, setStates] = useState([]);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);
  const columns = [
    {
      name: 'Username',
      selector: (row) => row.username,
      sortable: true,
    },
    {
      name: 'Email',
      selector: (row) => row.email,
      sortable: true,
    },
    {
      name: 'City',
      selector: (row) => row.city,
      sortable: true,
    },
    {
      name: 'Phone',
      selector: (row) => row.phone,
      sortable: true,
    },
    {
      name: 'State',
      selector: (row) => row.country_name,
      sortable: true,
    },
    {
      name: 'Actions',
      button: true,
      cell: (data) => (
        <div className="flex">
          <Link
            href={`/${redirectLink}/edit`}
            onClick={(e) => localStorage.setItem(record, JSON.stringify(data))}
          >
            <FaRegEdit className="text-success mx-1 h-[20px] w-[20px] cursor-pointer" />
          </Link>
        </div>
      ),
    },
  ];

  const fetchUsers = (page) => {
    setLoading(true);
    const url = `http://localhost:5000/users?${
      filterLink && 'role=' + filterLink + '&'
    }is_active=1&is_blocked=0&page=${page}&limit=${perPage}&sort_by=created_at&order=desc`;

    axios
      .get(url)
      .then((response) => {
        setData(response.data.user);
        setTotalRows(response.data.total);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  const handlePageChange = (page) => {
    fetchUsers(page);
  };

  const handlePerRowsChange = (newPerPage, page) => {
    setLoading(true);
    const url = `http://localhost:5000/users?${
      filterLink && 'role=' + filterLink + '&'
    }is_active=1&is_blocked=0&page=${page}&limit=${perPage}&sort_by=created_at&order=desc`;

    axios
      .get(url)
      .then((response) => {
        setData(response.data.user);
        setPerPage(newPerPage);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  useEffect(() => {
    axios
      .get('http://localhost:5000/countries')
      .then((res) => {
        setStates(res.data.data);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  }, []);

  const handleSort = (column, sortDirection) => {
    setLoading(true);
    const url = `http://localhost:5000/users?${
      filterLink && 'role=' + filterLink + '&'
    }is_active=1&is_blocked=0&limit=${perPage}&sort_by=${
      column.name
    }&order=${sortDirection}`;

    axios
      .get(url)
      .then((response) => {
        setData(response.data.user);
        setLoading(false);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
  };

  useEffect(() => {
    fetchUsers(1);
  }, []);

  return (
    <DataTable
      title={Heading}
      columns={columns}
      data={data}
      progressPending={loading}
      pagination
      paginationServer
      paginationTotalRows={totalRows}
      onChangeRowsPerPage={handlePerRowsChange}
      onChangePage={handlePageChange}
      onSort={handleSort}
    />
  );
}

export default Page;
