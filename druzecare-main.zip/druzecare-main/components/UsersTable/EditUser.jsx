'use client';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Cookies from 'js-cookie';

function Page({ record, show = false }) {
  const [states, setStates] = useState([]);
  const [profile, setProfile] = useState({});

  useEffect(() => {
    axios
      .get('http://localhost:5000/countries')
      .then((res) => {
        setStates(res.data.data);
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });
    setProfile(JSON.parse(localStorage.getItem(record)));
  }, []);

  const handleChangeInput = (event) => {
    const { name, value } = event.target;
    setProfile((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleChangeCheckbox = (event) => {
    const { name, checked, value } = event.target;

    setProfile((prevState) => ({
      ...prevState,
      [name]: checked ? value : '',
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const data = {
      firstname: e.target.firstname.value,
      lastname: e.target.lastname.value,
      phone: e.target.phone.value,
      country_id:
        e.target.country_id.options[e.target.country_id.selectedIndex].id,
      city: e.target.city.value,
      is_visible: e.target.is_visible.checked,
      is_active: e.target.is_active.checked,
      is_blocked: e.target.is_blocked.checked,
    };
    axios
      .patch('http://localhost:5000/user/profile/update', data, {
        withCredentials: true,
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
      });

    localStorage.removeItem(record);
  };

  return (
    <div className="flex justify-center">
      <form className="w-full max-w-lg" onSubmit={handleSubmit}>
        <div className="-mx-3 mb-6 flex flex-wrap">
          <div className="mb-6 w-full px-3">
            <label
              className="mb-2 block text-xs font-bold uppercase tracking-wide text-gray-700"
              for="grid-first-name"
            >
              First Name
            </label>
            <input
              className="mb-3 block w-full appearance-none rounded border border-red-500 bg-gray-200 px-4 py-3 leading-tight text-gray-700 focus:bg-white focus:outline-none"
              id="grid-first-name"
              type="text"
              placeholder="Jane"
              name="firstname"
              value={profile?.firstname || ''}
              onChange={handleChangeInput}
            />
          </div>
          <div className="w-full px-3">
            <label
              className="mb-2 block text-xs font-bold uppercase tracking-wide text-gray-700"
              for="grid-last-name"
            >
              Last Name
            </label>
            <input
              className="block w-full appearance-none rounded border border-gray-200 bg-gray-200 px-4 py-3 leading-tight text-gray-700 focus:border-gray-500 focus:bg-white focus:outline-none"
              id="grid-last-name"
              type="text"
              placeholder="Doe"
              name="lastname"
              value={profile?.lastname || ''}
              onChange={handleChangeInput}
            />
          </div>
        </div>
        <div className="-mx-3 mb-2 flex flex-wrap">
          <div className=" mb-6 w-full px-3">
            <label
              className="mb-2 block text-xs font-bold uppercase tracking-wide text-gray-700"
              for="grid-city"
            >
              Phone
            </label>
            <input
              className="block w-full appearance-none rounded border border-gray-200 bg-gray-200 px-4 py-3 leading-tight text-gray-700 focus:border-gray-500 focus:bg-white focus:outline-none"
              id="grid-city"
              type="text"
              placeholder="021 xxx xxxx"
              name="phone"
              value={profile?.phone || ''}
              onChange={handleChangeInput}
            />
          </div>
        </div>
        <div className="-mx-3 mb-2 flex flex-wrap">
          <div className=" mb-6 w-full px-3">
            <label
              className="mb-2 block text-xs font-bold uppercase tracking-wide text-gray-700"
              for="grid-city"
            >
              City
            </label>
            <input
              className="block w-full appearance-none rounded border border-gray-200 bg-gray-200 px-4 py-3 leading-tight text-gray-700 focus:border-gray-500 focus:bg-white focus:outline-none"
              id="grid-city"
              type="text"
              placeholder="United States"
              name="city"
              value={profile?.city || ''}
              onChange={handleChangeInput}
            />
          </div>
          <div className=" mb-6 w-full px-3">
            <label
              className="mb-2 block text-xs font-bold uppercase tracking-wide text-gray-700"
              for="grid-state"
            >
              State
            </label>
            <div className="relative">
              <select
                className="block w-full appearance-none rounded border border-gray-200 bg-gray-200 px-4 py-3 pr-8 leading-tight text-gray-700 focus:border-gray-500 focus:bg-white focus:outline-none"
                id="grid-state"
                name="country_id"
                onChange={handleChangeInput}
              >
                {states.map((el, i) => (
                  <option
                    key={el._id}
                    id={el._id}
                    selected={el._id === profile?.country_id}
                  >
                    {el.name}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                <svg
                  className="h-4 w-4 fill-current"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                </svg>
              </div>
            </div>
          </div>
          {show && (
            <div className="w-full p-3">
              <div className="md:w-1/3"></div>
              <label className="block font-bold text-gray-500 md:w-2/3">
                <input
                  className="mr-2 leading-tight"
                  type="checkbox"
                  name="is_visible"
                  checked={profile?.is_visible}
                  onChange={handleChangeCheckbox}
                />
                <span className="text-sm">Is Visible</span>
              </label>
            </div>
          )}
          {false && (
            <>
              <div className="w-full p-3">
                <div className="md:w-1/3"></div>
                <label className="block font-bold text-gray-500 md:w-2/3">
                  <input
                    className="mr-2 leading-tight"
                    type="checkbox"
                    name="is_active"
                    checked={profile?.is_active}
                    onChange={handleChangeCheckbox}
                  />
                  <span className="text-sm">Is Active</span>
                </label>
              </div>
              <div className="w-full p-3">
                <div className="md:w-1/3"></div>
                <label className="block font-bold text-gray-500 md:w-2/3">
                  <input
                    className="mr-2 leading-tight"
                    type="checkbox"
                    name="is_blocked"
                    checked={profile?.is_blocked}
                    onChange={handleChangeCheckbox}
                  />
                  <span className="text-sm">Is Blocked</span>
                </label>
              </div>
            </>
          )}
          <div className="w-full p-3 md:w-1/2">
            <div className="md:w-1/3"></div>
            <div className="md:w-2/3">
              <button
                className="focus:shadow-outline rounded bg-green-500 px-4 py-2 font-bold text-white shadow hover:bg-green-400 focus:outline-none"
                type="submit"
              >
                Update
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}

export default Page;
