'use client';
import React from 'react';
import ChatCard from '../Chat/ChatCard';
import { useAppSelector } from '@/state/hooks';

const Dashboard = () => {
  const { user } = useAppSelector((state) => state.auth.user);

  return (
    <>
      <div className="2xl:gap-7.5 md:grid-cols-2 md:gap-6 xl:grid-cols-4 grid grid-cols-1 gap-4">
        <div className="xl:col-span-8 col-span-12">
          <h1 className="p-4 text-5xl">Hi! {user?.firstname}</h1>
          {/* <ChatCard />  */}
        </div>
      </div>
    </>
  );
};

export default Dashboard;
