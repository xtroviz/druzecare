'use client';
import React, { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import { redirect } from 'next/navigation';
import { useAppDispatch } from '@/state/hooks';
import { setUser } from '@/reducers/authReducer';
import Cookies from 'js-cookie';
import { refreshUser } from '@/components/actions/actions';

export default function DefaultLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [userRole, setUserRole] = useState('');
  const dispatch = useAppDispatch();

  useEffect(() => {
    refreshUser();
    const user = JSON.parse(Cookies.get('currentUser'));
    dispatch(setUser(user));
    setUserRole(user.user.role.toLowerCase().replace(' ', ''));
  }, []);

  useEffect(() => {
    const { auth } = JSON.parse(Cookies.get('currentUser'));
    if (!auth) {
      redirect('/login');
    }
  }, [userRole]);

  return (
    <>
      {/* <!-- ===== Page Wrapper Start ===== --> */}
      <div className="flex h-screen overflow-hidden">
        {/* <!-- ===== Sidebar Start ===== --> */}
        <Sidebar
          userRole={userRole}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
        {/* <!-- ===== Sidebar End ===== --> */}

        {/* <!-- ===== Content Area Start ===== --> */}
        <div className="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">
          {/* <!-- ===== Header Start ===== --> */}
          <Header
            userRole={userRole}
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
          />
          {/* <!-- ===== Header End ===== --> */}

          {/* <!-- ===== Main Content Start ===== --> */}
          <main>
            <div className="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
              {children}
            </div>
          </main>
          {/* <!-- ===== Main Content End ===== --> */}
        </div>
        {/* <!-- ===== Content Area End ===== --> */}
      </div>
      {/* <!-- ===== Page Wrapper End ===== --> */}
    </>
  );
}
