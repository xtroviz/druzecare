import React from 'react';
import Footer from '../../components/common/Footer';
import Header from '../../components/common/Header';
import getTranslation from '@/lib/i18n/getTranslation';
import Default from '@/components/Layouts/Default';

export default async function DefaultLayout({ params, children }) {
  const translation = await getTranslation(params.locale);

  return (
    <>
      <Default>
        <Header translation={translation} />
        {children}
        <Footer translation={translation} />
      </Default>
    </>
  );
}
