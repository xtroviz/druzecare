'use client';
import React, { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '@/state/hooks';
import { setUser } from '@/reducers/authReducer';
import Cookies from 'js-cookie';
import { refreshUser } from '@/components/actions/actions';

export default function DefaultLayout({ children }) {
  const user = useAppSelector((state) => state.auth.user);
  const dispatch = useAppDispatch();
  useEffect(() => {
    refreshUser()
     dispatch(setUser(JSON.parse(Cookies.get('currentUser'))));
 
  }, []);

  return (
    <>
      <main>{children}</main>
    </>
  );
}
