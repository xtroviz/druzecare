'use client';
import React, { useEffect } from 'react';
import Cookies from 'js-cookie';
import EditUser from '@/components/UsersTable/EditUser';

const Profile = () => {
  useEffect(() => {
    const { user } = JSON.parse(Cookies.get('currentUser'));
    localStorage.setItem('edit_profile', JSON.stringify(user));
  }, []);

  return <EditUser record={'edit_profile'} show={true} />;
};

export default Profile;
