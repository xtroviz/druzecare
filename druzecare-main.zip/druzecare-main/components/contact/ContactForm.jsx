'use client';
import React from 'react';

import axios from 'axios';
import Swal from 'sweetalert2';

const ContactSection1 = ({ name, phone, email, address, message, submit }) => {
  var toast = Swal.mixin({
    toast: true,
    icon: 'success',
    title: 'General Title',
    animation: true,
    position: 'top-right',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    },
  });

  const handlesContactSubmit = (e) => {
    e.preventDefault();
    axios
      .post(
        'http://localhost:5000/contact-us/create',
        {
          name: e.target.name.value,
          email: e.target.email.value,
          phone: e.target.phone.value,
          address: e.target.address.value,
          message: e.target.message.value,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      )
      .then((res) => {
        if (res.data.status && res.data.status == 201) {
          toast.fire({
            animation: true,
            title: res.data.message,
          });
        } else {
          toast.fire({
            icon: 'error',
            animation: true,
            title: res.data.message,
          });
        }
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        toast.fire({
          icon: 'error',
          animation: true,
          title: err.message,
        });
      });
  };

  return (
    <form onSubmit={handlesContactSubmit}>
      <input
        type="text"
        name="name"
        id="name"
        className="my-4 w-full bg-[#f5f5f5] p-5"
        placeholder={name}
      />
      <input
        type="number"
        name="phone"
        id="phone"
        className="my-4 w-full bg-[#f5f5f5] p-5"
        placeholder={phone}
      />
      <input
        type="email"
        name="email"
        id="email"
        className="my-4 w-full bg-[#f5f5f5] p-5"
        placeholder={email}
      />
      <input
        type="text"
        name="address"
        id="address"
        className="my-4 w-full bg-[#f5f5f5] p-5"
        placeholder={address}
      />
      <textarea
        name="message"
        rows="4"
        id="message"
        className="my-4 w-full bg-[#f5f5f5] p-5"
        placeholder={message}
      ></textarea>
      <button
        className={`shippori-mincho-bold rounded-full bg-[#2e4049] px-6 py-3 font-extrabold text-white`}
        type="submit"
      >
        {submit}
      </button>
    </form>
  );
};

export default ContactSection1;
