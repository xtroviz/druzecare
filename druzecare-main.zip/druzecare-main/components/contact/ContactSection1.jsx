import React from 'react';

import {
  FaFacebook,
  FaTwitter,
  FaInstagram,
  FaPinterest,
  FaRegEnvelope,
  FaPhoneAlt,
} from 'react-icons/fa';
import ContactForm from '@/components/contact/ContactForm';

const ContactSection1 = ({ translation }) => {
  return (
    <div className="container mx-auto grid grid-cols-1 gap-10 px-4 py-10 md:grid-cols-2 md:px-8 lg:px-32">
      <div className="">
        <h4 className={`sue-ellen  textRed mb-2 text-3xl`}>
          {translation('views.main.about-us')}
        </h4>
        <h3 className={`shippori-mincho-bold text-3xl`}>
          {translation('views.main.get-in-touch')}
        </h3>
        <p className="my-4">{translation('views.main.get-in-touch-desc-1')}</p>
        <div className="p-5">
          <div className="flex items-center">
            <div className="flex w-[4.6rem] items-center bg-[#efefef] p-3">
              <FaRegEnvelope className="textRed pl-3 text-4xl" />
            </div>
            <div className="p-5">
              <h3 className={`shippori-mincho-bold text-lg`}>
                {translation('views.main.message')}
              </h3>
              <p className={`shippori-mincho-bold text-base`}>
                {translation('views.main.support-email')}
              </p>
            </div>
          </div>
          <div className="flex items-center">
            <div className="flex w-[4.6rem] items-center bg-[#efefef] p-3">
              <FaPhoneAlt className="textRed pl-3 text-4xl" />
            </div>
            <div className="p-5">
              <h3 className={`shippori-mincho-bold text-lg`}>
                {translation('views.main.contact-us')}
              </h3>
              <p className={`shippori-mincho-bold text-base`}>
                {translation('views.main.contact-number')}
              </p>
            </div>
          </div>
        </div>
        <h3 className={`shippori-mincho-bold text-xl`}>
          {translation('views.main.follow-us')}
        </h3>
        <p className="my-4 pr-3">
          {translation('views.main.get-in-touch-desc-2')}
        </p>
        <div className="flex py-2">
          <FaFacebook className="text-color mx-3 ml-0 text-xl" />
          <FaTwitter className="text-color mx-3 text-xl" />
          <FaInstagram className="text-color mx-3 text-xl" />
          <FaPinterest className="text-color mx-3 text-xl" />
        </div>
      </div>
      <div className="bg-[#efefef] p-10">
        <ContactForm
          name={translation('views.main.enter-your-name')}
          email={translation('views.main.email-address')}
          address={translation('views.main.address')}
          phone={translation('views.main.phone-number')}
          message={translation('views.main.your-message')}
          submit={translation('views.main.submit')}
        />
      </div>
    </div>
  );
};

export default ContactSection1;
