import React from 'react';
import backgroundImage from '@/public/main-banner.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

import getTranslation from '@/lib/i18n/getTranslation';

const HomeBanner = async ({ params }) => {
  const translation = await getTranslation(params.locale);
  // {translation('views.main.title')}
  return (
    <div className="bg-cover bg-center">
      <div
        className="items-left justify-left flex h-full w-full bg-gray-900 bg-opacity-50"
        style={{
          backgroundImage: `url(${backgroundImage.src})`,
          backgroundPosition: 'center',
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          width: '100vw',
          height: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'left',
          padding: '10px',
        }}
      >
        <div className="container mx-auto grid grid-cols-1 gap-6 text-left md:grid-cols-2 lg:grid-cols-2">
          <div>
            <h2 className={`sue-ellen  text-4xl text-white`}>
              {translation('views.main.need-help')}
            </h2>
            <h1
              className={` shippori-mincho-bold text-6xl font-extrabold text-white first-letter:uppercase`}
            >
              {translation('views.main.being-life-saver')}
            </h1>
            <h3 className={`${styles.povertyLine}`}>
              {' '}
              <span className="rounded-full text-white">
                {translation('views.main.below-poverty')}
              </span>
            </h3>
            <div className="flex flex-col lg:flex-row">
              <a
                href="/"
                className="bgBrandRed mt-4 rounded-full px-6 py-4 text-sm font-medium uppercase text-white focus:outline-none lg:mr-4"
              >
                {translation('views.main.donate')}
              </a>
              <a
                href="/"
                className="bgWhite mt-4 rounded-full px-6 py-4 text-sm font-medium uppercase text-black focus:outline-none lg:ml-0 lg:mr-4"
              >
                {translation('views.main.discover')}
              </a>
            </div>
          </div>
          <div>&nbsp;</div>
        </div>
      </div>
    </div>
  );
};

export default HomeBanner;
