import React from 'react';
import about3 from '@/public/home-about.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

const HomeBanner = ({ translation }) => {
  return (
    <div>
      <div className="container -my-20 mx-auto">
        <div className="grid grid-cols-1 gap-0 md:grid-cols-3">
          <div className={` ${styles.aboutG1} px-10 py-16 text-black`}>
            <h3 className={` shippori-mincho-bold textNavyBlue text-3xl`}>
              {translation('views.main.home-section-2-first-title')}
            </h3>
            <p className="my-3">
              {translation('views.main.home-section-2-first-desc')}
            </p>
            <Link
              href="/"
              className="bgWhite mt-4 rounded-full px-6 py-4 text-sm font-medium uppercase text-black focus:outline-none"
            >
              {translation('views.main.discover')}
            </Link>
          </div>

          <div className={` ${styles.aboutG2} px-10 py-16`}>
            <h3 className={` shippori-mincho-bold text-3xl text-white`}>
              {translation('views.main.become-a-member')}
            </h3>
            <p className="my-3 text-white">
              {translation('views.main.home-section-2-second-desc')}
            </p>
            <Link
              href="/"
              className="mt-4 text-lg font-medium uppercase text-white underline focus:outline-none"
            >
              {translation('views.main.join-us-now')}
            </Link>
          </div>

          <div className="relative">
            <Image src={about3} className="h-full w-full" />
            <div className="absolute inset-0 bg-opacity-50"></div>
          </div>
        </div>
      </div>
      <div className="mb-20"></div>
    </div>
  );
};

export default HomeBanner;
