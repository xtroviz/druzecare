'use client';

import React from 'react';
import causes1 from '@/public/causes1.png';
import causes2 from '@/public/causes2.png';
import causes3 from '@/public/causes3.png';
import causes4 from '@/public/causes4.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
const responsive = {
  superLargeDesktop: {
    // the naming can be any, depends on you.
    breakpoint: { max: 4000, min: 3000 },
    items: 5,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
  },
  tablet: {
    breakpoint: { max: 1024, min: 768 },
    items: 2,
  },
  mobile: {
    breakpoint: { max: 767, min: 0 },
    items: 1,
  },
};

const HomeBanner = () => {
  return (
    <div>
      <section className="donation-carousel p-8 md:p-28">
        <div className="container mx-auto">
          <h4 className={` sue-ellen  textRed text-3xl`}>
            {/* {translation('views.main.our-cases')} */}
          </h4>
          <div className="flex items-center justify-between">
            <div>
              <h3 className={`shippori-mincho-bold text-3xl`}>
                {/* {translation('views.main.help-lots-of-people')} */}
              </h3>
            </div>
            <div>
              <Link
                href="/"
                className="bg-red rounded-full px-6 py-4 text-sm font-medium uppercase text-white focus:outline-none"
              >
                More Causes
              </Link>
            </div>
          </div>
        </div>

        <div className="py-10"></div>

        <Carousel responsive={responsive}>
          <div className={` mr-5 `}>
            <article className="bg-white">
              <Image src={causes1} className="w-full" />
              <div className="px-5 pb-6 pt-10">
                <h3 className={` shippori-mincho-bold text-xl`}>
                  Big charity: build school for poor children
                </h3>
                <div className="my-5 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-300">
                  <div className="bgBrandRed h-2 w-56 rounded-full "></div>
                </div>
                <div className="columns-2">
                  <h4 className={` shippori-mincho-bold text-left text-base`}>
                    Raised - $5M
                  </h4>
                  <h4
                    className={` shippori-mincho-bold textRed text-right text-base`}
                  >
                    Goal - $10M
                  </h4>
                </div>
                <Link
                  href="/"
                  className={`bgBlack mt-4 inline-block rounded-full px-8 py-3 font-medium uppercase text-white`}
                >
                  Donate
                </Link>
              </div>
            </article>
          </div>
          <div className={` mr-5 `}>
            <article className="bg-white">
              <Image src={causes2} className="w-full" />
              <div className="px-5 pb-6 pt-10">
                <h3 className={` shippori-mincho-bold text-xl`}>
                  Big charity: build school for poor children
                </h3>
                <div className="my-5 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-300">
                  <div className="bgBrandRed h-2 w-56 rounded-full "></div>
                </div>
                <div className="columns-2">
                  <h4 className={` shippori-mincho-bold text-left text-base`}>
                    Raised - $5M
                  </h4>
                  <h4
                    className={` shippori-mincho-bold textRed text-right text-base`}
                  >
                    Goal - $10M
                  </h4>
                </div>
                <Link
                  href="/"
                  className={`bgBlack mt-4 inline-block rounded-full px-8 py-3 font-medium uppercase text-white`}
                >
                  Donate
                </Link>
              </div>
            </article>
          </div>
          <div className={` mr-5`}>
            <article className="bg-white">
              <Image src={causes3} className="w-full" />
              <div className="px-5 pb-6 pt-10">
                <h3 className={` shippori-mincho-bold text-xl`}>
                  Big charity: build school for poor children
                </h3>
                <div className="my-5 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-300">
                  <div className="bgBrandRed h-2 w-56 rounded-full "></div>
                </div>
                <div className="columns-2">
                  <h4 className={` shippori-mincho-bold text-left text-base`}>
                    Raised - $5M
                  </h4>
                  <h4
                    className={` shippori-mincho-bold textRed text-right text-base`}
                  >
                    Goal - $10M
                  </h4>
                </div>
                <Link
                  href="/"
                  className={`bgBlack mt-4 inline-block rounded-full px-8 py-3 font-medium uppercase text-white`}
                >
                  Donate
                </Link>
              </div>
            </article>
          </div>
          <div className={` mr-5 `}>
            <article className="bg-white">
              <Image src={causes3} className="w-full" />
              <div className="px-5 pb-6 pt-10">
                <h3 className={` shippori-mincho-bold text-xl`}>
                  Big charity: build school for poor children
                </h3>
                <div className="my-5 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-300">
                  <div className="bgBrandRed h-2 w-56 rounded-full "></div>
                </div>
                <div className="columns-2">
                  <h4 className={` shippori-mincho-bold text-left text-base`}>
                    Raised - $5M
                  </h4>
                  <h4
                    className={` shippori-mincho-bold textRed text-right text-base`}
                  >
                    Goal - $10M
                  </h4>
                </div>
                <Link
                  href="/"
                  className={`bgBlack mt-4 inline-block rounded-full px-8 py-3 font-medium uppercase text-white`}
                >
                  Donate
                </Link>
              </div>
            </article>
          </div>
          <div className={` mr-5 `}>
            <article className="bg-white">
              <Image src={causes2} className="w-full" />
              <div className="px-5 pb-6 pt-10">
                <h3 className={` shippori-mincho-bold text-xl`}>
                  Big charity: build school for poor children
                </h3>
                <div className="my-5 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-300">
                  <div className="bgBrandRed h-2 w-56 rounded-full "></div>
                </div>
                <div className="columns-2">
                  <h4 className={` shippori-mincho-bold text-left text-base`}>
                    Raised - $5M
                  </h4>
                  <h4
                    className={` shippori-mincho-bold textRed text-right text-base`}
                  >
                    Goal - $10M
                  </h4>
                </div>
                <Link
                  href="/"
                  className={`bgBlack mt-4 inline-block rounded-full px-8 py-3 font-medium uppercase text-white`}
                >
                  Donate
                </Link>
              </div>
            </article>
          </div>
          <div className={` mr-5`}>
            <article className="bg-white">
              <Image src={causes3} className="w-full" />
              <div className="px-5 pb-6 pt-10">
                <h3 className={` shippori-mincho-bold text-xl`}>
                  Big charity: build school for poor children
                </h3>
                <div className="my-5 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-300">
                  <div className="bgBrandRed h-2 w-56 rounded-full "></div>
                </div>
                <div className="columns-2">
                  <h4 className={` shippori-mincho-bold text-left text-base`}>
                    Raised - $5M
                  </h4>
                  <h4
                    className={` shippori-mincho-bold textRed text-right text-base`}
                  >
                    Goal - $10M
                  </h4>
                </div>
                <Link
                  href="/"
                  className={`bgBlack mt-4 inline-block rounded-full px-8 py-3 font-medium uppercase text-white`}
                >
                  Donate
                </Link>
              </div>
            </article>
          </div>
        </Carousel>
      </section>

      <div className="float-none"></div>
    </div>
  );
};

export default HomeBanner;
