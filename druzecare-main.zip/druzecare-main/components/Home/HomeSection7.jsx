// 'use client';

import React from 'react';
import project from '@/public/project.png';
import project1 from '@/public/project1.png';
import project2 from '@/public/project2png.png';
import project3 from '@/public/project3png.png';
import icon3 from '@/public/icon3.png';
import icon4 from '@/public/icon4.png';
import icon5 from '@/public/icon5.png';
import icon6 from '@/public/icon6.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

const HomeBanner = ({ translation }) => {
  return (
    <div className="bg-white">
      <section className="">
        <div className="grid md:grid-cols-9 lg:grid-cols-12">
          <div className="col-span-9 bg-gray-900 p-10 text-gray-50 md:col-span-6">
            <h4 className={`sue-ellen  textRed mb-3 text-2xl md:text-3xl`}>
              {translation('views.main.About-us')}
            </h4>
            <h3 className={`shippori-mincho-bold mb-3 text-2xl md:text-3xl`}>
              {translation('views.main.Help-People')},<br />
              {translation('views.main.Our-Main-Goals')}
            </h3>
            <p className="mb-8 mt-3">
              {translation('views.main.About-us-description')}
            </p>
            <Link
              href="/"
              className="bgBrandRed mt-3 rounded-full px-6 py-4 text-sm font-medium uppercase text-white focus:outline-none"
            >
              {translation('views.main.More-Project')}
            </Link>
          </div>
          <div className="col-span-9 flex items-center justify-center md:col-span-3">
            <Image
              src={project}
              className={`block w-full ${styles.img_full}`}
            />
          </div>
          <div className="col-span-9 flex items-center justify-center md:col-span-4 lg:col-span-3">
            <Image
              src={project1}
              className={`block w-full ${styles.img_full}`}
            />
          </div>
          <div className="col-span-9 flex items-center justify-center md:col-span-5">
            <Image
              src={project2}
              className={`block w-full ${styles.img_full}`}
            />
          </div>
          <div className="bgBrandRed items-left col-span-9  flex flex-col justify-end p-5 md:col-span-5 md:p-10 lg:col-span-3">
            <div className="flex">
              <Link
                href="/"
                className="bgBrandRedDark btnSmall mb-3 me-3 rounded-full px-5 py-1 text-sm font-medium text-white focus:outline-none"
              >
                {translation('views.main.education')}
              </Link>
              <Link
                href="/"
                className="bgBrandRedDark btnSmall rounded-full px-5  py-1 text-sm font-medium text-white focus:outline-none"
              >
                {translation('views.main.health')}
              </Link>
            </div>

            <h3
              className={`shippori-mincho-bold ${styles.about_more_than_one} mb-12 mt-3 text-lg tracking-widest text-white md:text-2xl`}
            >
              {translation('views.main.more-that-one-life-changed')}
            </h3>
          </div>
          <div className="col-span-9 flex items-center justify-center md:col-span-4">
            <Image
              src={project3}
              className={`block w-full ${styles.img_full}`}
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomeBanner;
