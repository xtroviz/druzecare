'use client';

import React from 'react';
import backgroundImage from '@/public/section5bg.png';
import becomev from '@/public/becomev.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

import axios from 'axios';
import Swal from 'sweetalert2';
import Cookies from 'js-cookie';

const HomeBanner = ({ translations }) => {
  var toast = Swal.mixin({
    toast: true,
    icon: 'success',
    title: 'General Title',
    animation: true,
    position: 'top-right',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    },
  });

  const handlesVolunteerSubmit = (e) => {
    e.preventDefault();
    axios
      .post(
        'http://localhost:5000/volunteer/create',
        {
          name: e.target.name.value,
          email: e.target.email.value,
          phone: e.target.phone.value,
          message: e.target.message.value,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      )
      .then((res) => {
        if (res.data.status && res.data.status == 201) {
          toast.fire({
            animation: true,
            title: res.data.message,
          });
        } else {
          toast.fire({
            icon: 'error',
            animation: true,
            title: res.data.message,
          });
        }
      })
      .catch((err) => {
        Cookies.set('removeCookies', 'true');
        toast.fire({
          icon: 'error',
          animation: true,
          title: err.message,
        });
      });
  };

  return (
    <div
      className="py-16"
      style={{
        backgroundImage: `url(${backgroundImage.src})`,
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        width: '100vw',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'left',
      }}
    >
      <section className={`container mx-auto p-10 md:p-28`}>
        <div className="container mx-auto">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className={`p-5 text-white md:p-10`}>
              <h4 className={`sue-ellen  text-3xl`}>
                {translations.howWeHelp}
              </h4>
              <h3 className={`shippori-mincho-bold text-3xl`}>
                {translations.joinCommunity}{' '}
              </h3>
              <p className="my-3 text-white">
                {translations.joinCommunityDesc1}
              </p>

              <Image src={becomev} className="w-full" />
              <p className="p-3"></p>
              <Link
                href="/"
                className="bgBrandRed mt-4 rounded-full px-6 py-4 text-sm font-medium uppercase text-white focus:outline-none"
              >
                {translations.donateNow}
              </Link>
            </div>

            <div className={`border-2 border-gray-400 p-5 md:p-10`}>
              <h3 className={`shippori-mincho-bold mb-5 text-3xl text-white`}>
                {translations.becomeVolunteer}
              </h3>
              <form method="POST" onSubmit={handlesVolunteerSubmit}>
                <input
                  type="text"
                  name="name"
                  className="mt-1 block w-full border-separate border-2 border-gray-400 bg-transparent px-2 py-4 focus:outline-0"
                  placeholder="Full Name*"
                />
                <input
                  name="email"
                  type="email"
                  className="mt-4 block w-full border-separate border-2 border-gray-400 bg-transparent px-2 py-4 focus:outline-0"
                  placeholder="Email Address*"
                  required
                />
                <input
                  name="phone"
                  type="tel"
                  className="mt-4 block w-full border-separate border-2 border-gray-400 bg-transparent px-2 py-4 focus:outline-0"
                  placeholder="Phone Number*"
                  required
                />
                <textarea
                  name="message"
                  className="mt-4 block w-full border-separate border-2 border-gray-400 bg-transparent px-2 py-4 focus:outline-0"
                  rows={4}
                  placeholder="Message"
                ></textarea>
                <div className="mb-2">
                  <button
                    type="submit"
                    className="mt-5 h-10 rounded-full bg-gray-50 px-5 text-gray-800 transition-colors duration-150"
                  >
                    {translations.submit}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="clear-both"></div>
      </section>
    </div>
  );
};

export default HomeBanner;
