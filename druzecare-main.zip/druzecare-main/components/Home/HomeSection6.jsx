import React from 'react';
import icon1 from '@/public/icon1.png';
import icon2 from '@/public/icon2.png';
import icon3 from '@/public/icon3.png';
import icon4 from '@/public/icon4.png';
import icon5 from '@/public/icon5.png';
import icon6 from '@/public/icon6.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

const HomeBanner = ({ translation }) => {
  return (
    <div className="bg-white py-8 md:py-16">
      <section className={`container mx-auto p-5 md:p-28`}>
        <div className="container mx-auto">
          <h4 className={` sue-ellen  text-center text-2xl md:text-3xl`}>
            {translation('views.main.what-we-do-2')}
          </h4>
          <h3
            className={`shippori-mincho-bold text-center text-2xl md:text-3xl`}
          >
            {translation('views.main.we-do-it-for-people')}
          </h3>
          <br></br>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
            <div className={`p-3 text-center`}>
              <Image src={icon1} className="inline-block" />
              <h3 className={`shippori-mincho-bold text-lg `}>
                {translation('views.main.what-we-do-2-title-1')}
              </h3>
              <p>{translation('views.main.what-we-do-2-desc-1')}</p>
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon2} className="inline-block" />
              <h3 className={`shippori-mincho-bold text-lg `}>
                {translation('views.main.what-we-do-2-title-2')}
              </h3>
              <p>{translation('views.main.what-we-do-2-desc-2')}</p>
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon3} className="inline-block" />
              <h3 className={`shippori-mincho-bold text-lg `}>
                {translation('views.main.what-we-do-2-title-3')}
              </h3>
              <p>{translation('views.main.what-we-do-2-desc-3')}</p>
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon4} className="inline-block" />
              <h3 className={`shippori-mincho-bold text-lg `}>
                {translation('views.main.what-we-do-2-title-4')}
              </h3>
              <p>{translation('views.main.what-we-do-2-desc-4')}</p>
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon5} className="inline-block" />
              <h3 className={`shippori-mincho-bold text-lg `}>
                {translation('views.main.what-we-do-2-title-5')}
              </h3>
              <p>{translation('views.main.what-we-do-2-desc-5')}</p>
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon6} className="inline-block" />
              <h3 className={`shippori-mincho-bold text-lg `}>
                {translation('views.main.what-we-do-2-title-6')}
              </h3>
              <p>{translation('views.main.what-we-do-2-desc-6')}</p>
            </div>
          </div>
        </div>
        <div className="clear-both"></div>
      </section>
    </div>
  );
};

export default HomeBanner;
