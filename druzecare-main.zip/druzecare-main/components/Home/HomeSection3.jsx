import React from 'react';
import about3 from '@/public/home-about.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

const HomeBanner = ({ translation }) => {
  return (
    <div>
      <section className="aboutUs container mx-auto p-8 md:p-16 lg:p-28">
        <div className="grid grid-cols-1 gap-8 text-center">
          <div className={`p-8 text-black md:p-10`}>
            <h4 className={` sue-ellen  textRed text-3xl`}>
              {translation('views.main.about-us')}
            </h4>
            <h3 className={`shippori-mincho-bold text-3xl`}>
              {translation('views.main.help-people-our-main-goal')}
            </h3>
            <p className="my-3">
              {translation('views.main.help-people-our-main-goal-desc-1')}
            </p>
            <p>{translation('views.main.help-people-our-main-goal-desc-2')}</p>
            <p className="p-3"></p>
            <Link
              href="/"
              className="bgBrandRed mt-4 rounded-full px-6 py-4 text-sm font-medium uppercase text-white focus:outline-none"
            >
              {translation('views.main.more-about')}
            </Link>
          </div>

          {/* <div className={`bgLightGray p-8 md:p-10 `}>
            <ul className={`grid grid-cols-1 gap-4 md:grid-cols-2`}>
              <li className="my-1">
                <svg
                  className={`bgSkyBlue mr-3 inline h-6 w-6 rounded-full p-1 text-black dark:text-black`}
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <path
                    stroke="currentColor"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="m5 12 5 5 9.6-9"
                  />
                </svg>
                {translation('views.main.food-donation')}
              </li>
              {/* Add more list items here 
            </ul>
            <br></br>
            <h3 className={` shippori-mincho-bold text-2xl`}>
              {translation('views.main.total-duration')}
            </h3>
            <div className="my-5 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-300">
              <div className="bgBrandRed h-2 w-56 rounded-full "></div>
            </div>
            <div className="flex flex-col justify-between md:flex-row">
              <h4 className={` shippori-mincho-bold text-left text-xl`}>
                {translation('views.main.collection')} - $5M
              </h4>
              <h4 className={` shippori-mincho-bold text-right text-xl`}>
                {translation('views.main.goal')} - $10M
              </h4>
            </div>
            <Link
              href="/"
              className="mt-4 inline-block rounded-full bg-white px-8 py-3 font-medium uppercase text-black"
            >
              {translation('views.main.donate-now')}
            </Link>
          </div> */}
        </div>
      </section>
    </div>
  );
};

export default HomeBanner;
