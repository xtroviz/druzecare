import React from 'react';
import CallToAction from '@/components/common/CallToAction';
import VolunteerCard from '@/components/common/VolunteerCard';

function HomeSection9({ translation, main_heading, secondary_heading }) {
  return (
<div className="w-full space-y-4 bg-neutral-100 p-5 md:p-28 text-center">
  <h4 className="text-center __className_9c7bc7 text-3xl textRed">{main_heading}</h4>
  <div className="__className_b70e47">
    <h1 className="text-2xl font-bold">{secondary_heading}</h1>
  </div>
  <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
    <VolunteerCard name={translation('views.main.martin-luther')} />
    <VolunteerCard name={translation('views.main.keira-knightley')} />
    <VolunteerCard name={translation('views.main.jack-sparrow')} />
    <CallToAction translation={translation} />
  </div>
</div>

  );
}

export default HomeSection9;
