import React from 'react';

import Newsletter from '@/components/common/NewsletterForm';

const HomeBanner = ({ translation }) => {
  return (
    <div className="bg-[#ff6d6d]">
      <div className="mx-auto w-full rounded-lg px-6 py-16 md:w-1/2  lg:pl-24 lg:pr-64">
        <h4 className={`sue-ellen text-3xl text-white`}>
          {translation('views.main.subscribe')}
        </h4>
        <h3
          className={`shippori-mincho-bold text-3xl tracking-wider text-white`}
        >
          {translation('views.main.newsletter')}
        </h3>
        <p className="py-4 text-white">
          {translation('views.main.newsletter-signup')}
        </p>

        <Newsletter
          text_placeholder={translation('views.main.enter-your-email')}
          text_submit={translation('views.main.send')}
        />
      </div>
    </div>
  );
};

export default HomeBanner;
