import React from 'react';
import icon1 from '@/public/project1.png';
import icon3 from '@/public/project3png.png';

import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';

import TestimonialsCard from '@/components/common/TestimonialsCard';
import { IoChevronBackOutline, IoChevronForwardOutline } from 'react-icons/io5';

const HomeBanner = ({ translation }) => {
  return (
    <div className="bg-white py-16">
      <section className="container mx-auto p-5 md:p-28">
        <div className="container mx-auto">
          <h4 className={`sue-ellen  textRed text-center text-3xl md:text-4xl`}>
            {translation('views.main.testimonials')}
          </h4>
          <h3
            className={`shippori-mincho-bold mb-8 text-center text-3xl md:text-4xl`}
          >
            {translation('views.main.what-people-say')}
          </h3>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <TestimonialsCard translation={translation} image={icon1} />
            <TestimonialsCard translation={translation} image={icon3} />
          </div>

          <div class="mt-3 flex w-full items-center justify-center">
            <div class="rounded-full border-2 p-5">
              <IoChevronBackOutline className="h-6 w-6 text-gray-700 dark:text-gray-300" />
            </div>
            <hr class="my-8 h-0.5 h-1 w-96 rounded border-0 bg-gray-100 md:my-10 dark:bg-gray-300" />
            <div class="rounded-full border-2 p-5">
              <IoChevronForwardOutline className="h-6 w-6 text-gray-700 dark:text-gray-300" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <div className="p-3 text-center">
              <h3
                className={`shippori-mincho-bold py-3 text-4xl font-extrabold tracking-wide md:text-5xl`}
              >
                200k
              </h3>
              <p>{translation('views.main.recieved-donations')}</p>
              <p>{translation('views.main.from-our-people')}</p>
            </div>
            <div className="p-3 text-center">
              <h3
                className={`shippori-mincho-bold py-3 text-4xl font-extrabold tracking-wide md:text-5xl`}
              >
                99k
              </h3>
              <p>{translation('views.main.project-done-with')}</p>
              <p>{translation('views.main.the-help-of-donators')}</p>
            </div>
            <div className="p-3 text-center">
              <h3
                className={`shippori-mincho-bold py-3 text-4xl font-extrabold tracking-wide md:text-5xl`}
              >
                200k
              </h3>
              <p>{translation('views.main.people-we-helped')}</p>
              <p>{translation('views.main.on-2020')}</p>
            </div>
            <div className="p-3 text-center">
              <h3
                className={`shippori-mincho-bold py-3 text-4xl font-extrabold tracking-wide md:text-5xl`}
              >
                10.7k
              </h3>
              <p>{translation('views.main.with-our-volunteers')}</p>
              <p>{translation('views.main.solved-many-problems')}</p>
            </div>
          </div>

          <hr className="mx-auto my-4 h-0.5 rounded border-0 bg-gray-100 md:my-10 dark:bg-gray-300" />

          <div className="grid grid-cols-5 gap-0">
            <div className={`p-3 text-center`}>
              <Image src={icon3} className="inline-block" />
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon3} className="inline-block" />
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon3} className="inline-block" />
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon3} className="inline-block" />
            </div>
            <div className={`p-3 text-center`}>
              <Image src={icon3} className="inline-block" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomeBanner;
