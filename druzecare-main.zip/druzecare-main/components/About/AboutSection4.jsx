import React from 'react';

import styles from '../styles/Home.module.css';

import Newsletter from '@/components/common/NewsletterForm';

const AboutSection4 = ({ translation }) => {
  return (
    <div className="bg_red_overlay col-span-1 py-10 pl-5 pr-5 text-center md:pl-24 md:pr-56">
      <div className="mx-auto flex flex-col items-center p-5 md:p-10">
        <h4 className="__className_9c7bc7 text-3xl text-white">
          {translation('views.main.subscribe')}
        </h4>
        <h3
          className={`shippori-mincho-bold py-2 text-3xl tracking-wider text-white`}
        >
          {translation('views.main.newsletter')}
        </h3>
        <p className="pb-6 pt-3 text-white">
          {translation('views.main.about-newsletter-desc')}
        </p>
        <div className="w-full md:w-4/5">
          <Newsletter
            text_placeholder={translation('views.main.enter-your-email')}
            text_submit={translation('views.main.send')}
          />
        </div>
      </div>
    </div>
  );
};

export default AboutSection4;
