import React from 'react';
import Image from 'next/image';
import icon3 from '@/public/project1.png';

import OurGoalsTasks from '@/components/common/OurGoalsTasks';

function AboutSection3({ translation }) {
  return (
    <div className="container mx-auto grid grid-cols-1 px-5 pb-10 pt-10 md:grid-cols-2 md:px-20 md:pb-40">
      <div className="md:pr-10">
        <h3 className={`shippori-mincho-bold w-full text-3xl md:w-4/5`}>
          {translation('views.main.our-goal')}
        </h3>
        <p className="my-4">{translation('views.main.our-goal-desc-1')}</p>
        <div className="grid grid-cols-2 gap-5 py-4">
          <OurGoalsTasks name={translation('views.main.task-1')} />
          <OurGoalsTasks name={translation('views.main.task-2')} />
          <OurGoalsTasks name={translation('views.main.task-3')} />
          <OurGoalsTasks name={translation('views.main.task-4')} />
          <OurGoalsTasks name={translation('views.main.task-5')} />
        </div>
        <p className="my-4">{translation('views.main.our-goal-desc-2')}</p>
      </div>
      <div className="md:pl-10">
        <h3 className={`shippori-mincho-bold w-full text-3xl md:w-4/5`}>
          {translation('views.main.our-mission')}
        </h3>
        <p className="my-4">{translation('views.main.our-mission-desc-1')}</p>
        <div className="relative">
          <Image src={icon3} className="h-auto w-full md:h-[22rem]" />
          <div className="absolute bottom-0 left-0 flex flex-col items-center justify-center bg-[#77d7d3] md:bottom-[-3rem] md:left-[1.5rem] md:w-[20rem]">
            <p
              className={`shippori-mincho-bold pb-1 text-5xl font-extrabold tracking-wider text-[#2e4049]`}
            >
              20000+
            </p>
            <p
              className={`shippori-mincho-bold pb-1 tracking-wider text-[#2e4049]`}
            >
              {translation('views.main.our-mission-thousand-people-helped')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AboutSection3;
