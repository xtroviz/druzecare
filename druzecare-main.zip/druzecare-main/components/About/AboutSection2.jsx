import React from 'react';
import Image from 'next/image';
import icon3 from '@/public/project1.png';

function AboutSection2() {
  return (
    <div className="container mx-auto px-5 md:px-20">
      <hr className="mx-auto my-4 h-0.5 rounded border-0 bg-gray-100 dark:bg-gray-300 md:my-10" />
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-0 px-5 md:px-24">
        <div className={`p-3 text-center`}>
          <Image src={icon3} className="inline-block" />
        </div>
        <div className={`p-3 text-center`}>
          <Image src={icon3} className="inline-block" />
        </div>
        <div className={`p-3 text-center`}>
          <Image src={icon3} className="inline-block" />
        </div>
        <div className={`p-3 text-center`}>
          <Image src={icon3} className="inline-block" />
        </div>
        <div className={`p-3 text-center`}>
          <Image src={icon3} className="inline-block" />
        </div>
      </div>
      <hr className="mx-auto my-4 h-0.5 rounded border-0 bg-gray-100 dark:bg-gray-300 md:my-10" />
    </div>
  );
  
}

export default AboutSection2;
