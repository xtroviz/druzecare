'use server';
import { cookies } from 'next/headers';
import axios from 'axios';

export const refreshUser = async () => {
  const cookieStore = cookies();
  const deleteCookies = cookieStore.get('removeCookies')?.value;

  if (deleteCookies === 'true') {
    cookieStore.delete('currentUser');
    cookieStore.delete('accessToken');
    cookieStore.delete('refreshToken');
    cookieStore.delete('role');
    cookieStore.delete('removeCookies');
  } else {
    axios.post(
      'http://localhost:5000/refresh',
      {},
      {
        withCredentials: true,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json',
        },
      }
    );
  }
  return !deleteCookies || deleteCookies === 'false' ? false : true;
};
