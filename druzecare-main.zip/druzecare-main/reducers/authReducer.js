import { createSlice } from '@reduxjs/toolkit';

export const authReducer = createSlice({
  name: 'auth',
  initialState: {
    user: {},
  },
  reducers: {
    setUser: (state, action) => {
      state.user = state.user
        ? {
            ...state.user,
            ...action.payload,
          }
        : action.payload;
    },
  },
});

// Action creators are generated for each case reducer function
export const { setUser } = authReducer.actions;

export default authReducer.reducer;
