import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { getLocales } from '../helpers/locales';

export const fetchLocales = createAsyncThunk(
  'messages/fetchLocales',
  async (lang, thunkAPI) => {
    try {
      const response = await getLocales(lang);
      return response;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

export const messagesReducer = createSlice({
  name: 'messages',
  initialState: {
    lang: 'en',
    messages: {},
  },
  reducers: {
    setMessages: (state, action) => {
      state.lang = action.payload.lang;
      state.messages = action.payload.messages;
    },
  },
});

// Action creators are generated for each case reducer function
export const { setMessages } = messagesReducer.actions;

export default messagesReducer.reducer;
