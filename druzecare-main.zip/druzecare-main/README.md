#Druze Care
