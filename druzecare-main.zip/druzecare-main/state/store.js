import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../reducers/authReducer';

export const makeStore = () => {
  return configureStore({
    reducer: {
      auth: authReducer,
    },
  });
};
